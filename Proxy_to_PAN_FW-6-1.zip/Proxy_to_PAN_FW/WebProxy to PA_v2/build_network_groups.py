#!/usr/bin/env python3
"""
build_network_groups.py  —  CCD Platform
Generates the 3-tier PAN-OS source Network-Object hierarchy from IPAM datasets.

  Tier-1  Site-Type / BU class      (e.g. NG-DATACENTER, NG-DR, NG-CLOUD, NG-CORPORATE)
  Tier-2  Location breakout         (SITE_CODE for named facilities; provider for cloud;
                                      state + East/West region for Corporate;
                                      function+state for Retail/MinuteClinic/Optical)
  Tier-3  Concatenated CIDR object  (the ONLY tier where IP literals exist)

Tier-1 classification is taken from location_master (authoritative LOCATION_TYPE owner),
joined onto all_IP_networks by SITE_CODE — NOT from the denormalized LOCATION_TYPE copy
carried in all_IP_networks. High-volume retail tiers are emitted as EDL feeds.

Outputs:
  <out>/ccd_network_groups.set      PAN-OS set-format CLI (Tier-3 objects, Tier-3/2/1 groups, EDL stanzas)
  <out>/edl_feeds/NG-<FN>-<ST>.txt  flat CIDR lists for the EDL host
  <out>/ng_manifest.csv             Tier1/Tier2/Tier3/CIDR-count manifest
  <out>/ng_reconciliation.csv       rows where all_IP_networks LOCATION_TYPE != location_master

Versioning: SCRIPT __version__ = MAJOR.MINOR.PATCH ; emits a #VERSION header in the .set file.

Usage:
  python build_network_groups.py \
      --ipam all_IP_networks_v20260525r5.csv \
      --lm   location_master_v5_11.csv \
      --retail retail_networks_v2_9.csv \
      --out  ./out \
      --edl-host https://edl.cvshealth.internal/ccd \
      [--tier1-source lm|ipam] [--dry-run]
"""
from __future__ import annotations
import argparse, csv, ipaddress, json, os, re, sys
from collections import defaultdict, OrderedDict

__version__ = "1.0.0"

# ----------------------------------------------------------------------
# Canonical Site-Type / BU taxonomy.
# Maps BOTH the long LOCATION_TYPE values AND the raw short codes that
# appear un-normalized in location_master (CI/CO/IS/TP/MO/RT/SP/HP/CP/NH)
# to a single canonical Tier-1 class. Edit here to extend the taxonomy.
# ----------------------------------------------------------------------
TIER1_TAXONOMY = {
    # long forms
    "Datacenter": "DATACENTER", "DataCenter": "DATACENTER",
    "COLO": "COLO",
    "Cloud": "CLOUD", "Cloud-Azure": "CLOUD", "Cloud-GCP": "CLOUD", "Cloud-AWS": "CLOUD",
    "Corporate": "CORPORATE", "Field-Office": "CORPORATE",
    "Distribution": "DISTRIBUTION",
    "Call-Center": "CALL-CENTER", "CVS-CC": "CALL-CENTER",
    "Specialty": "SPECIALTY",
    "CarePlus": "CAREPLUS", "Field-Clinic": "CAREPLUS",
    "Omnicare": "OMNICARE",
    "Mail-Order": "MAIL-ORDER",
    "Coram": "CORAM",
    "DMZ": "DMZ",
    "Partner": "PARTNER",
    "Internet-Facing": "INTERNET-FACING",
    "P2P-WAN": "P2P-WAN", "SNAT": "SNAT",
    "DR": "DR",
    "Retail": "RETAIL", "MinuteClinic": "MINUTECLINIC", "Optical": "OPTICAL",
    "VoIP-Hub": "NAAS-HUB", "NH": "NAAS-HUB",
    # raw short codes (un-normalized LOCATION_TYPE values — see remediation prompt)
    "CI": "COLO", "CO": "CORPORATE", "IS": "CLOUD", "TP": "PARTNER",
    "MO": "MAIL-ORDER", "RT": "RETAIL", "SP": "SPECIALTY",
    "HP": "CAREPLUS", "CP": "CAREPLUS",
}

CLOUD_PROVIDER_TOKEN = {"AZR": "AZURE", "GCP": "GCP", "AWS": "AWS"}

# States east of the Mississippi (river-east bank convention). Override via --east if needed.
EAST_OF_MISSISSIPPI = set(
    "AL CT DE FL GA IL IN KY ME MD MA MI MS NH NJ NY NC OH PA RI SC TN VT VA WV WI DC".split()
)

RETAIL_FACILITY_MAP = {"Retail-Store": "PHARMA", "MinuteClinic": "MINUTECLINIC", "Optical": "OPTICAL"}
RETAIL_T1 = {"PHARMA": "NG-RETAIL", "MINUTECLINIC": "NG-MINUTECLINIC", "OPTICAL": "NG-OPTICAL"}


def clean(s: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "-", str(s).upper()).strip("-")


def state_from_sitecode(sc: str) -> str:
    parts = str(sc).split("_")
    return parts[2] if len(parts) >= 3 else "UNK"


def read_stamped_csv(path: str):
    """Read a CCD CSV that has #-prefixed header stamps before the real header row."""
    with open(path, newline="", encoding="utf-8-sig") as f:
        lines = f.readlines()
    hdr_idx = next(i for i, ln in enumerate(lines)
                   if not ln.startswith("#") and "," in ln)
    reader = csv.DictReader(lines[hdr_idx:])
    return list(reader)


def valid_cidr(c: str) -> bool:
    if not c or "/" not in str(c):
        return False
    try:
        ipaddress.ip_network(c.strip(), strict=False)
        return True
    except ValueError:
        return False


def build(args):
    ipam = read_stamped_csv(args.ipam)
    lm = read_stamped_csv(args.lm)

    # authoritative LOCATION_TYPE + canonical name keyed by SITE_CODE
    lm_loctype = {r["SITE_CODE"]: r.get("LOCATION_TYPE", "") for r in lm}
    lm_canon = {r["SITE_CODE"]: r.get("CANONICAL_NAME", "") for r in lm}

    t3 = OrderedDict()                  # AO-name -> set(cidr)
    t2_children = defaultdict(set)      # NG-T2 -> set(AO-name)
    t1_children = defaultdict(set)      # NG-T1 -> set(NG-T2)
    reconciliation = []                 # rows where ipam loctype != lm loctype
    unclassified = []

    for r in ipam:
        cidr = (r.get("CIDR") or "").strip()
        if not valid_cidr(cidr):
            continue
        sc = r.get("SITE_CODE") or ""

        # ---- Tier-1 classification ----
        ipam_lt = r.get("LOCATION_TYPE") or ""
        lm_lt = lm_loctype.get(sc, "")
        if ipam_lt and lm_lt and ipam_lt != lm_lt:
            reconciliation.append([sc, cidr, ipam_lt, lm_lt])

        chosen_lt = lm_lt if (args.tier1_source == "lm" and lm_lt) else (ipam_lt or lm_lt)
        # DR is encoded in the SITE_CODE suffix, overrides LOCATION_TYPE
        if sc.endswith("_DR"):
            t1 = "DR"
        else:
            t1 = TIER1_TAXONOMY.get(chosen_lt)
        if not t1:
            unclassified.append([sc, cidr, chosen_lt])
            continue

        # ---- CLOUD: Tier-2 = provider ----
        if t1 == "CLOUD":
            tok = sc.split("_")[1] if len(sc.split("_")) > 1 else ""
            prov = CLOUD_PROVIDER_TOKEN.get(tok)
            if not prov:
                rd = r.get("ROUTING_DOMAIN", "") or ""
                prov = ("AZURE" if "Azure" in rd else "GCP" if "GCP" in rd
                        else "AWS" if "AWS" in rd else "AZURE")
            ao = f"AO-{prov}"
            t2 = f"NG-{prov}"
            t3.setdefault(ao, set()).add(cidr)
            t2_children[t2].add(ao)
            t1_children["NG-CLOUD"].add(t2)
            continue

        # ---- CORPORATE: Tier-2 = state, nested under East/West region ----
        if t1 == "CORPORATE":
            st = state_from_sitecode(sc)
            region = "EAST" if st in args.east else "WEST"
            label = clean(lm_canon.get(sc) or sc)
            t2_state = f"NG-CORP-{st}"
            ao = f"AO-CORP-{label}"
            t3.setdefault(ao, set()).add(cidr)
            t2_children[t2_state].add(ao)
            t1_children[f"NG-CORP-{region}"].add(t2_state)
            t1_children["NG-CORPORATE"].add(f"NG-CORP-{region}")
            continue

        # ---- named-facility classes: Tier-2 = SITE_CODE (readable via canonical name) ----
        label = clean(lm_canon.get(sc) or sc)
        ao = f"AO-{t1}-{label}"
        t2 = f"NG-{t1}-{label}"
        t3.setdefault(ao, set()).add(cidr)
        t2_children[t2].add(ao)
        t1_children[f"NG-{t1}"].add(t2)

    # ---- Retail / MinuteClinic / Optical -> EDL feeds (Tier-2 = function+state) ----
    retail_edls = defaultdict(list)
    if args.retail:
        for r in read_stamped_csv(args.retail):
            fn = RETAIL_FACILITY_MAP.get(r.get("FACILITY_TYPE", ""))
            if not fn:
                continue
            st = (r.get("STATES") or "").strip().upper()[:2] or state_from_sitecode(r.get("SITE_CODE", ""))
            cidr = (r.get("CIDR") or "").strip()
            if valid_cidr(cidr):
                retail_edls[f"NG-{fn}-{st}"].append(cidr)
        for g in retail_edls:
            fn = g.split("-")[1]
            t1_children[RETAIL_T1[fn]].add(g)

    if args.dry_run:
        print(json.dumps({
            "dry_run": True,
            "tier1_classes": sorted(t1_children),
            "tier2_groups": len(t2_children),
            "tier3_objects": len(t3),
            "retail_edls": len(retail_edls),
            "reconciliation_rows": len(reconciliation),
            "unclassified_rows": len(unclassified),
        }, indent=2))
        return

    os.makedirs(args.out, exist_ok=True)
    edl_dir = os.path.join(args.out, "edl_feeds")
    os.makedirs(edl_dir, exist_ok=True)

    for g, cidrs in retail_edls.items():
        with open(os.path.join(edl_dir, g + ".txt"), "w") as f:
            f.write("\n".join(sorted(set(cidrs))) + "\n")

    # flatten Tier-3 into individual address objects
    addr, t3_groups = OrderedDict(), OrderedDict()
    for ao in sorted(t3):
        members = []
        for c in sorted(t3[ao]):
            name = "addr-" + c.replace("/", "_").replace(".", "-")
            addr[name] = c
            members.append(name)
        t3_groups[ao] = members

    out_set = os.path.join(args.out, "ccd_network_groups.set")
    with open(out_set, "w") as f:
        w = f.write
        w(f"# CCD Source Network Groups — 3-tier hierarchical model\n")
        w(f"#VERSION={__version__}\n")
        w(f"#TIER1_SOURCE={args.tier1_source}\n")
        w(f"#IPAM={os.path.basename(args.ipam)}  LM={os.path.basename(args.lm)}"
          f"  RETAIL={os.path.basename(args.retail) if args.retail else 'none'}\n")
        w("# Tier-1=Site-Type/BU  Tier-2=Location  Tier-3=concatenated CIDR object."
          "  CIDRs live ONLY at Tier-3.\n\n")
        w("# ===== TIER-3: address objects =====\n")
        for name, c in addr.items():
            w(f"set address {name} ip-netmask {c}\n")
        w("\n# ===== TIER-3: location CIDR groups =====\n")
        for ao, m in t3_groups.items():
            w(f"set address-group {ao} static [ " + " ".join(m) + " ]\n")
        w("\n# ===== TIER-2: location breakout =====\n")
        for t2 in sorted(t2_children):
            w(f"set address-group {t2} static [ " + " ".join(sorted(t2_children[t2])) + " ]\n")
        w("\n# ===== TIER-1: Site-Type/BU classes =====\n")
        for t1 in sorted(t1_children):
            w(f"set address-group {t1} static [ " + " ".join(sorted(t1_children[t1])) + " ]\n")
        w("\n# ===== EDL feeds: Retail / MinuteClinic / Optical (Tier-2 = function+state) =====\n")
        for g in sorted(retail_edls):
            w(f'set external-list {g} type ip recurring five-minute url "{args.edl_host}/{g}.txt"\n')

    with open(os.path.join(args.out, "ng_manifest.csv"), "w", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["Tier1_Class", "Tier2_Location", "Tier3_Object", "CIDR_count"])
        for t1 in sorted(t1_children):
            for t2 in sorted(t1_children[t1]):
                if t2 in t2_children:
                    for ao in sorted(t2_children[t2]):
                        wr.writerow([t1, t2, ao, len(t3.get(ao, []))])
                else:
                    wr.writerow([t1, t2, "(EDL feed)", "—"])

    with open(os.path.join(args.out, "ng_reconciliation.csv"), "w", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["SITE_CODE", "CIDR", "all_IP_networks_LOCATION_TYPE", "location_master_LOCATION_TYPE"])
        wr.writerows(reconciliation)

    if unclassified:
        with open(os.path.join(args.out, "ng_unclassified.csv"), "w", newline="") as f:
            wr = csv.writer(f)
            wr.writerow(["SITE_CODE", "CIDR", "LOCATION_TYPE"])
            wr.writerows(unclassified)


    # ---- INDEPENDENT NETWORK-OBJECT CATALOG (generic, tool-agnostic) ----
    # Schema: TIER, OBJECT_NAME, PARENT, CLASS, MEMBER_TYPE, VALUE, CIDR_COUNT, SOURCE
    catalog = []
    # Tier-1
    for t1 in sorted(t1_children):
        cls = t1.replace('NG-','')
        catalog.append(dict(TIER=1, OBJECT_NAME=t1, PARENT='', CLASS=cls,
                            MEMBER_TYPE='group', VALUE=';'.join(sorted(t1_children[t1])),
                            CIDR_COUNT='', SOURCE='derived'))
    # Tier-2 (static groups)
    for t2 in sorted(t2_children):
        parent = next((t1 for t1 in t1_children if t2 in t1_children[t1]), '')
        cls = parent.replace('NG-','') if parent else ''
        catalog.append(dict(TIER=2, OBJECT_NAME=t2, PARENT=parent, CLASS=cls,
                            MEMBER_TYPE='group', VALUE=';'.join(sorted(t2_children[t2])),
                            CIDR_COUNT='', SOURCE='static'))
    # Tier-2 (EDL feeds)
    for g in sorted(retail_edls):
        parent = next((t1 for t1 in t1_children if g in t1_children[t1]), '')
        catalog.append(dict(TIER=2, OBJECT_NAME=g, PARENT=parent, CLASS=parent.replace('NG-',''),
                            MEMBER_TYPE='edl', VALUE=f'{args.edl_host}/{g}.txt',
                            CIDR_COUNT=len(set(retail_edls[g])), SOURCE='edl'))
    # Tier-3 (concatenated CIDR objects)
    for ao in sorted(t3):
        parent = next((t2 for t2 in t2_children if ao in t2_children[t2]), '')
        catalog.append(dict(TIER=3, OBJECT_NAME=ao, PARENT=parent, CLASS='',
                            MEMBER_TYPE='cidr-list', VALUE=';'.join(sorted(t3[ao])),
                            CIDR_COUNT=len(t3[ao]), SOURCE='static'))

    import datetime
    stamp = datetime.date.today().strftime('%Y%m%d')
    cat_csv = os.path.join(args.out, f'network_object_catalog_v{stamp}.csv')
    cols = ['TIER','OBJECT_NAME','PARENT','CLASS','MEMBER_TYPE','VALUE','CIDR_COUNT','SOURCE']
    with open(cat_csv,'w',newline='') as f:
        f.write(f'#STEM=network_object_catalog\n#VERSION={stamp}\n#ROWS={len(catalog)}\n')
        f.write(f'#TOOL=build_network_groups.py v{__version__}\n#END_HEADER\n')
        wr=csv.DictWriter(f, fieldnames=cols); wr.writeheader()
        for row in catalog: wr.writerow(row)

    # YAML: hierarchical nesting for human/HTML consumption
    cat_yaml = os.path.join(args.out, f'network_object_catalog_v{stamp}.yaml')
    with open(cat_yaml,'w') as f:
        f.write(f'# network_object_catalog v{stamp}  (generated by build_network_groups.py v{__version__})\n')
        f.write('# 3-tier source network-object hierarchy. CIDRs live only at tier 3.\n')
        f.write(f'version: "{stamp}"\n')
        f.write(f'tool: "build_network_groups.py v{__version__}"\n')
        f.write('tier1_classes:\n')
        for t1 in sorted(t1_children):
            f.write(f'  - name: {t1}\n    class: {t1.replace("NG-","")}\n    tier2:\n')
            for t2 in sorted(t1_children[t1]):
                if t2 in t2_children:
                    f.write(f'      - name: {t2}\n        type: group\n        tier3:\n')
                    for ao in sorted(t2_children[t2]):
                        f.write(f'          - name: {ao}\n            cidr_count: {len(t3.get(ao,[]))}\n')
                        f.write(f'            cidrs: [{", ".join(sorted(t3.get(ao,[])))}]\n')
                else:
                    cc = len(set(retail_edls.get(t2,[])))
                    f.write(f'      - name: {t2}\n        type: edl\n        cidr_count: {cc}\n')
                    f.write(f'        url: "{args.edl_host}/{t2}.txt"\n')


    print(json.dumps({
        "version": __version__,
        "tier1_classes": len(t1_children),
        "tier2_groups": len(t2_children),
        "tier3_objects": len(t3_groups),
        "address_objects": len(addr),
        "retail_edls": len(retail_edls),
        "reconciliation_rows": len(reconciliation),
        "unclassified_rows": len(unclassified),
        "output_set": out_set,
        "catalog_csv": cat_csv,
        "catalog_yaml": cat_yaml,
    }, indent=2))


def main():
    ap = argparse.ArgumentParser(description="Generate 3-tier PAN-OS source network-group hierarchy from CCD IPAM datasets.")
    ap.add_argument("--ipam", required=True, help="all_IP_networks CSV")
    ap.add_argument("--lm", required=True, help="location_master CSV (authoritative LOCATION_TYPE)")
    ap.add_argument("--retail", help="retail_networks CSV (emits EDL feeds)")
    ap.add_argument("--out", default="./out", help="output directory")
    ap.add_argument("--edl-host", default="https://<edl-host>/ccd", help="base URL where EDL feed files are served")
    ap.add_argument("--tier1-source", choices=["lm", "ipam"], default="lm",
                    help="authoritative source for Tier-1 LOCATION_TYPE (default: lm)")
    ap.add_argument("--east", help="comma-separated state list for East region (overrides default Mississippi split)")
    ap.add_argument("--dry-run", action="store_true", help="report counts without writing files")
    args = ap.parse_args()
    args.east = set(args.east.split(",")) if args.east else EAST_OF_MISSISSIPPI
    if not os.path.exists(args.ipam) or not os.path.exists(args.lm):
        sys.exit("ERROR: --ipam and --lm must both exist")
    build(args)


if __name__ == "__main__":
    main()
