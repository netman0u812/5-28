#!/usr/bin/env python3
# =============================================================================
#  zscaler_category_edl_builder.py
# =============================================================================
#  WHAT THIS SCRIPT DOES (read this first)
#  -----------------------------------------------------------------------------
#  In Zscaler, security admins keep a hand-curated "custom URL category" -- for
#  example "CVSH-Enterprise-Allow-AI", the list of approved AI tools employees
#  are allowed to use. That list lives INSIDE the Zscaler portal; it is not a
#  file anywhere. We want our Palo Alto firewall to enforce the SAME list, so
#  the two security layers agree.
#
#  This script logs in to Zscaler, downloads the contents of that category, and
#  writes them out as a Palo Alto "EDL" (External Dynamic List) -- a plain text
#  file, one entry per line, that the firewall downloads on a schedule.
#
#  Because the Zscaler list is typed by humans, it is messy (bracketed entries
#  like evil[.]com, full URLs with paths, upper-case, stray spaces). The firewall
#  is strict and will reject a list with bad lines, so this script validates and
#  cleans every entry before writing.
#
#  HOW IT WORKS (the "accretive + aging" model)
#  -----------------------------------------------------------------------------
#  Each run produces a NEW version that COMBINES (a) what we published last time
#  with (b) what is valid in today's pull from Zscaler. We never silently drop a
#  previously-approved entry just because it momentarily disappeared from the
#  pull. We track two dates per entry:
#       first_seen = the date we first ever saw it
#       last_seen  = the most recent date Zscaler still listed it
#  Entries that stop appearing keep living in the list but stop advancing their
#  last_seen, so stale ones can be pruned later by date.
#
#  SAFETY GUARANTEES (why you can trust the output)
#  -----------------------------------------------------------------------------
#  1. EVERY entry is re-validated every run -- even previously published ones.
#  2. Malformed entries are NEVER written; they are bypassed and reported.
#  3. The final list is de-duplicated and hygiene-checked before writing.
#  4. Domains and IPs are split into two EDL files (PAN-OS uses different types).
#
#  AUTHENTICATION -- TWO ZSCALER FRAMEWORKS
#  -----------------------------------------------------------------------------
#  Zscaler tenants are on ONE of two API frameworks. Ask your Zscaler admin
#  which one you have, then set the matching environment variables:
#
#    OneAPI (the modern OAuth2 / Zidentity framework):
#        ZSCALER_CLIENT_ID, ZSCALER_CLIENT_SECRET, ZSCALER_VANITY_DOMAIN
#    Legacy (older obfuscated-API-key admin login):
#        ZIA_API_KEY, ZIA_USERNAME, ZIA_PASSWORD, ZIA_CLOUD  (e.g. zscalerthree.net)
#
#  Credentials come ONLY from environment variables -- NEVER type a password or
#  key on the command line (it would be saved in your shell history).
#
#  WHAT YOU GET AFTER A RUN (output files)
#  -----------------------------------------------------------------------------
#     <name>_domains.txt          <- clean domain EDL  (firewall downloads this)
#     <name>_ips.txt              <- clean IP EDL       (firewall downloads this)
#     <name>_state.json           <- the date-tracking memory (DO NOT delete)
#     <name>_report_<stamp>.txt   <- human-readable "what happened" report
#
#  HOW TO RUN IT (examples)
#  -----------------------------------------------------------------------------
#     # First, prove your login works and see the category names + IDs:
#     python zscaler_category_edl_builder.py --auth oneapi --list
#
#     # Then pull a category and build the EDL:
#     python zscaler_category_edl_builder.py --auth oneapi \
#         --category CVSH-Enterprise-Allow-AI --name CVSH-Enterprise-Allow-AI
#
#     # Preview without writing anything:
#     python zscaler_category_edl_builder.py --auth legacy \
#         --category CVSH-Enterprise-Allow-AI --dry-run
#
#  This script uses ONLY the Python standard library. Nothing to install.
# =============================================================================

from __future__ import annotations
import argparse          # parses command-line flags
import datetime          # today's date for first_seen / last_seen
import http.cookiejar    # holds the login cookie for the legacy framework
import ipaddress         # validates IPs / CIDRs correctly
import json              # reads/writes JSON (Zscaler responses + our state file)
import os                # file paths and environment variables
import re                # regular expressions for domain validation
import ssl               # secure HTTPS
import sys               # exit codes
import time              # millisecond timestamp for the legacy login
import urllib.parse      # url-encodes the OAuth2 token request body
import urllib.request    # makes the HTTPS calls (standard library)

# -----------------------------------------------------------------------------
#  VERSION  (CCD rule: one canonical __version__, MAJOR.MINOR.PATCH)
# -----------------------------------------------------------------------------
__version__ = "1.0.0"


# =============================================================================
#  SECTION 1 -- VALIDATION RULES  (identical philosophy to the SOC builder)
# =============================================================================
#  Copied in deliberately so this script is fully self-contained -- there is no
#  shared module to install, break, or forget. If you change a rule here, change
#  it in the SOC builder too.
# -----------------------------------------------------------------------------

# A valid domain name, punycode/IDN allowed (see SOC builder for the full
# breakdown of each part of this pattern).
DOMAIN_PATTERN = re.compile(
    r"^(?=.{1,253}$)(?!-)([A-Za-z0-9-]{1,63}\.)+([A-Za-z]{2,63}|xn--[A-Za-z0-9]{2,59})$"
)

# Bracketed "defanged" forms that must be turned back into a real dot.
DEFANG_PATTERN = re.compile(r"\[\.\]|\(\.\)|\[dot\]", re.IGNORECASE)


def looks_like_ip_or_cidr(token: str) -> bool:
    """
    Decide whether a piece of text is a valid IP address or CIDR range.

    WHAT IT DOES
    ------------
    Returns True for "8.8.8.8", "10.0.0.0/8", or a valid IPv6 address; False
    otherwise. Used to send IPs to the IP EDL and domains to the domain EDL.

    PARAMETERS
    ----------
    token : str
        One cleaned piece of text from the Zscaler category.

    RETURNS
    -------
    bool
        True if it is a valid IP or CIDR, False otherwise.
    """
    try:
        if "/" in token:
            ipaddress.ip_network(token, strict=False)
        else:
            ipaddress.ip_address(token)
        return True
    except ValueError:
        return False


def classify_and_clean(raw_value: str, counters: dict, advisories: dict):
    """
    Take ONE entry from a Zscaler category and decide what it is.

    WHAT IT DOES
    ------------
    Returns ("domain", value), ("ip", value), or (None, None). Auto-fixes the
    safe, common Zscaler-specific messiness (leading dots like ".chatgpt.com",
    URL paths like "site.com/login", defanging, upper-case, trailing dots) and
    rejects anything it cannot trust, recording every decision in 'counters'
    (totals) and 'advisories' (the actual values for human review).

    WHY IT WORKS THIS WAY
    ---------------------
    Zscaler category URLs often arrive as ".example.com" or "example.com/path"
    -- forms a firewall EDL does not want. We normalise those, then validate
    strictly. As with the SOC builder, anything that doesn't cleanly match a
    known-good shape is rejected, because one bad line can make PAN-OS reject
    the whole EDL.

    PARAMETERS
    ----------
    raw_value : str
        One entry exactly as Zscaler returned it.
    counters : dict
        Running tally per category. Mutated here.
    advisories : dict
        Lists of actual rejected values per reason. Mutated here.

    RETURNS
    -------
    tuple(str|None, str|None)
        ("domain", value) or ("ip", value) or (None, None).
    """
    # ---- Step 1: strip whitespace ----
    text = raw_value.strip()

    # ---- Step 2: drop blanks ----
    if text == "":
        counters["blank"] += 1
        return None, None

    # ---- Step 3: AUTO-FIX a leading dot:  ".chatgpt.com" -> "chatgpt.com" ----
    # Zscaler frequently stores a leading dot to mean "this domain and its
    # subdomains". PAN-OS domain EDLs already match subdomains, so we drop it.
    if text.startswith("."):
        text = text.lstrip(".")
        counters["leading_dot_fixed"] += 1

    # ---- Step 4: AUTO-FIX a URL path:  "site.com/login" -> "site.com" ----
    if "/" in text:
        text = text.split("/")[0]
        counters["path_stripped"] += 1

    # ---- Step 5: is it an IP / CIDR? (check before domain rules) ----
    if looks_like_ip_or_cidr(text):
        counters["ip_accepted"] += 1
        return "ip", text

    # ---- Step 6: AUTO-FIX defanging:  "evil[.]com" -> "evil.com" ----
    if DEFANG_PATTERN.search(text):
        text = DEFANG_PATTERN.sub(".", text)
        counters["defang_fixed"] += 1

    # ---- Step 7: reject email addresses ----
    if "@" in text:
        counters["email_rejected"] += 1
        advisories["email_rejected"].append(raw_value.strip())
        return None, None

    # ---- Step 8: AUTO-FIX trailing dot:  "evil.com." -> "evil.com" ----
    if text.endswith("."):
        text = text.rstrip(".")
        counters["trailing_dot_fixed"] += 1

    # ---- Step 9: AUTO-FIX upper-case ----
    lowered = text.lower()
    if lowered != text:
        counters["lowercased"] += 1
    text = lowered

    # ---- Step 10: FINAL domain validation ----
    if "." in text and DOMAIN_PATTERN.match(text):
        counters["domain_accepted"] += 1
        return "domain", text

    counters["invalid"] += 1
    advisories["invalid"].append(raw_value.strip())
    return None, None


# =============================================================================
#  SECTION 2 -- ZSCALER LOGIN + CATEGORY PULL
# =============================================================================
#  Two login paths, one for each Zscaler framework. Each returns the full list
#  of CUSTOM url categories as Python objects, which we then search.
# -----------------------------------------------------------------------------

def get_categories_oneapi(timeout: int):
    """
    Log in with the modern OneAPI (OAuth2 / Zidentity) framework and return the
    custom URL categories.

    WHAT IT DOES
    ------------
    1. Reads the three OneAPI environment variables.
    2. Exchanges them for a short-lived OAuth2 access token.
    3. Calls the ZIA API to list custom URL categories.

    PARAMETERS
    ----------
    timeout : int
        Seconds to wait for each HTTPS call.

    RETURNS
    -------
    list
        A list of category objects (dicts) as returned by Zscaler.

    RAISES
    ------
    KeyError
        If a required environment variable is missing (caller turns this into a
        friendly message).
    """
    client_id = os.environ["ZSCALER_CLIENT_ID"]
    client_secret = os.environ["ZSCALER_CLIENT_SECRET"]
    vanity_domain = os.environ["ZSCALER_VANITY_DOMAIN"]

    # --- get an OAuth2 token from the Zidentity login endpoint ---
    token_body = urllib.parse.urlencode({
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "audience": "https://api.zscaler.com",
    }).encode()
    token_request = urllib.request.Request(
        f"https://{vanity_domain}.zslogin.net/oauth2/v1/token",
        data=token_body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    context = ssl.create_default_context()
    with urllib.request.urlopen(token_request, timeout=timeout, context=context) as response:
        access_token = json.load(response)["access_token"]

    # --- call the ZIA API for custom URL categories ---
    cat_request = urllib.request.Request(
        "https://api.zsapi.net/zia/api/v1/urlCategories?customOnly=true",
        headers={"Authorization": f"Bearer {access_token}", "Accept": "application/json"},
    )
    with urllib.request.urlopen(cat_request, timeout=timeout, context=context) as response:
        return json.load(response)


def get_categories_legacy(timeout: int):
    """
    Log in with the legacy (obfuscated API key) framework and return the custom
    URL categories.

    WHAT IT DOES
    ------------
    1. Reads the four legacy environment variables.
    2. Builds the obfuscated key using Zscaler's published algorithm.
    3. Creates an authenticated session (cookie) and lists custom categories.
    4. Logs out so we don't leave a session hanging.

    THE OBFUSCATION ALGORITHM (Zscaler-documented)
    ----------------------------------------------
    Take the current time in milliseconds. Use its last 6 digits ('n') and
    n>>1 zero-padded to 6 digits ('r') to pick characters out of the raw API
    key. The result, plus the timestamp, is what you actually send. Sending the
    raw key fails. This is Zscaler's design, copied here exactly.

    PARAMETERS
    ----------
    timeout : int
        Seconds to wait for each HTTPS call.

    RETURNS
    -------
    list
        A list of category objects (dicts) as returned by Zscaler.

    RAISES
    ------
    KeyError
        If a required environment variable is missing.
    """
    api_key = os.environ["ZIA_API_KEY"]
    username = os.environ["ZIA_USERNAME"]
    password = os.environ["ZIA_PASSWORD"]
    cloud = os.environ.get("ZIA_CLOUD", "zscalerthree.net")

    # --- build the obfuscated key ---
    now_ms = int(time.time() * 1000)              # current time in milliseconds
    last6 = str(now_ms)[-6:]                       # 'n' = last 6 digits
    half = str(int(last6) >> 1).zfill(6)           # 'r' = n>>1, padded to 6
    obfuscated = "".join(api_key[int(d)] for d in last6) \
        + "".join(api_key[int(d) + 2] for d in half)

    base_url = f"https://zsapi.{cloud}/api/v1"

    # --- open a session that remembers the login cookie ---
    cookie_jar = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))

    login_body = json.dumps({
        "apiKey": obfuscated,
        "username": username,
        "password": password,
        "timestamp": now_ms,
    }).encode()
    login_request = urllib.request.Request(
        base_url + "/authenticatedSession",
        data=login_body,
        headers={"Content-Type": "application/json", "Cache-Control": "no-cache"},
    )
    opener.open(login_request, timeout=timeout)

    # --- pull custom categories, then always try to log out ---
    try:
        cat_request = urllib.request.Request(
            base_url + "/urlCategories?customOnly=true",
            headers={"Accept": "application/json"},
        )
        with opener.open(cat_request, timeout=timeout) as response:
            return json.load(response)
    finally:
        try:
            logout = urllib.request.Request(base_url + "/authenticatedSession", method="DELETE")
            opener.open(logout, timeout=15)
        except Exception:
            pass  # logout failure is not fatal; the session will expire anyway


def collect_members(category: dict):
    """
    Gather every URL/IP entry out of a Zscaler category object.

    WHAT IT DOES
    ------------
    A Zscaler category spreads its entries across several list fields. This
    pulls them all into one flat Python list so the validator can process them.

    PARAMETERS
    ----------
    category : dict
        One category object from the Zscaler API.

    RETURNS
    -------
    list
        Every raw entry string found in the category.
    """
    members = []
    for field in ("urls", "dbCategorizedUrls", "ipRanges",
                  "ipRangesRetainingParentCategory"):
        value = category.get(field)
        if isinstance(value, list):
            members.extend(value)
    return members


# =============================================================================
#  SECTION 3 -- STATE FILE (date memory) -- identical model to the SOC builder
# =============================================================================

def load_state(state_path: str) -> dict:
    """
    Load the first_seen/last_seen memory, or start empty on the first run.

    PARAMETERS
    ----------
    state_path : str
        Path to <name>_state.json.

    RETURNS
    -------
    dict
        { "entries": { "<value>": {"kind","first_seen","last_seen"}, ... } }
    """
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
                if "entries" not in data:
                    data["entries"] = {}
                return data
        except Exception:
            print(f"WARNING: state file {state_path} unreadable; starting fresh.")
            return {"entries": {}}
    return {"entries": {}}


def save_state(state_path: str, state: dict) -> None:
    """
    Write the date memory back to disk as readable JSON.

    PARAMETERS
    ----------
    state_path : str
        Path to <name>_state.json.
    state : dict
        Structure to save.
    """
    with open(state_path, "w", encoding="utf-8") as handle:
        json.dump(state, handle, indent=2, sort_keys=True)


# =============================================================================
#  SECTION 4 -- MERGE (accretive + aging) -- identical model to the SOC builder
# =============================================================================

def merge_into_state(today_entries: dict, state: dict, today: str) -> dict:
    """
    Combine today's validated Zscaler entries with the previously published set.

    WHAT IT DOES
    ------------
    New entry  -> add with first_seen = last_seen = today.
    Known + present today -> advance last_seen to today.
    Known + absent today  -> keep, leave last_seen alone (it ages).

    PARAMETERS
    ----------
    today_entries : dict
        { "<value>": "domain"|"ip" } valid in today's pull.
    state : dict
        Previously published memory (already re-validated by the caller).
    today : str
        "YYYY-MM-DD".

    RETURNS
    -------
    dict
        Updated state.
    """
    entries = state["entries"]
    for value, kind in today_entries.items():
        if value in entries:
            entries[value]["last_seen"] = today
            entries[value]["kind"] = kind
        else:
            entries[value] = {"kind": kind, "first_seen": today, "last_seen": today}
    return state


# =============================================================================
#  SECTION 5 -- WRITE OUTPUT (EDL files + report)
# =============================================================================

def write_edls(out_dir: str, name: str, state: dict):
    """
    Write the two clean EDL text files the firewall downloads.

    WHAT IT DOES
    ------------
    Splits merged entries into domains and IPs, sorts and de-duplicates them,
    and writes <name>_domains.txt and <name>_ips.txt with a single leading
    comment line. No dates go in the EDL itself.

    PARAMETERS
    ----------
    out_dir : str
        Output directory.
    name : str
        Base file name.
    state : dict
        Merged memory.

    RETURNS
    -------
    tuple(int, int)
        (domains_written, ips_written)
    """
    domains = sorted({v for v, m in state["entries"].items() if m["kind"] == "domain"})
    ips = sorted({v for v, m in state["entries"].items() if m["kind"] == "ip"})
    stamp = datetime.date.today().isoformat()

    domain_path = os.path.join(out_dir, f"{name}_domains.txt")
    with open(domain_path, "w", encoding="utf-8") as handle:
        handle.write(f"# {name} domain EDL  |  {len(domains)} entries  |  built {stamp}  |  builder v{__version__}\n")
        handle.write("\n".join(domains))
        if domains:
            handle.write("\n")

    ip_path = os.path.join(out_dir, f"{name}_ips.txt")
    with open(ip_path, "w", encoding="utf-8") as handle:
        handle.write(f"# {name} ip EDL  |  {len(ips)} entries  |  built {stamp}  |  builder v{__version__}\n")
        handle.write("\n".join(ips))
        if ips:
            handle.write("\n")

    return len(domains), len(ips)


def write_report(out_dir, name, category, auth, raw_count, counters, advisories,
                 added, refreshed, aged, total_domains, total_ips, stale,
                 revalidation_drops):
    """
    Write the human-readable "what happened this run" report.

    WHAT IT DOES
    ------------
    Tells the operator how many entries Zscaler returned, what was auto-fixed,
    what was rejected (with the actual values), how the merge changed the
    published set, and which entries are now stale. This is the data-quality
    management view.

    PARAMETERS
    ----------
    out_dir, name, category, auth : str
        Output dir, EDL base name, Zscaler category name, auth framework used.
    raw_count : int
        How many raw entries Zscaler returned for the category.
    counters, advisories : dict
        Tallies and the actual rejected values.
    added, refreshed, aged : int
        Merge outcome counts.
    total_domains, total_ips : int
        Final published counts.
    stale : list
        Entries past the staleness window.
    revalidation_drops : list
        Previously-published entries that failed re-validation and were removed.

    RETURNS
    -------
    str
        Path of the report written.
    """
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(out_dir, f"{name}_report_{stamp}.txt")

    rejected_total = (counters["blank"] + counters["email_rejected"] + counters["invalid"])

    lines = []
    lines.append(f"Zscaler Category EDL Build Report  --  {name}")
    lines.append("=" * 60)
    lines.append(f"Builder version : {__version__}")
    lines.append(f"Zscaler category: {category}")
    lines.append(f"Auth framework  : {auth}")
    lines.append(f"Run time        : {datetime.datetime.now().isoformat(timespec='seconds')}")
    lines.append(f"Raw entries pulled from Zscaler : {raw_count}")
    lines.append("")
    lines.append("-- AUTO-FIXED (safe corrections applied automatically) --")
    lines.append(f"  Leading dot removed (.site.com -> site.com)  : {counters['leading_dot_fixed']}")
    lines.append(f"  URL path stripped (site.com/x -> site.com)   : {counters['path_stripped']}")
    lines.append(f"  Defanged re-fanged (evil[.]com -> evil.com)  : {counters['defang_fixed']}")
    lines.append(f"  Trailing dot stripped                        : {counters['trailing_dot_fixed']}")
    lines.append(f"  Lower-cased                                  : {counters['lowercased']}")
    lines.append("")
    lines.append("-- REJECTED (bypassed, never written to the EDL) --")
    lines.append(f"  Blank entries        : {counters['blank']}")
    lines.append(f"  Email addresses      : {counters['email_rejected']}")
    lines.append(f"  Invalid / no TLD     : {counters['invalid']}")
    lines.append(f"  REJECTED TOTAL       : {rejected_total}")
    lines.append("")
    lines.append("-- RE-VALIDATION OF PREVIOUSLY-PUBLISHED ENTRIES --")
    lines.append(f"  Dropped because no longer valid : {len(revalidation_drops)}")
    lines.append("")
    lines.append("-- MERGE RESULT (accretive + aging) --")
    lines.append(f"  Brand-new entries added    : {added}")
    lines.append(f"  Existing entries refreshed : {refreshed}")
    lines.append(f"  Entries not in today's pull: {aged}  (kept, last_seen unchanged)")
    lines.append("")
    lines.append("-- PUBLISHED EDL TOTALS --")
    lines.append(f"  Domains : {total_domains}  -> {name}_domains.txt")
    lines.append(f"  IPs     : {total_ips}  -> {name}_ips.txt")
    lines.append(f"  Stale (not seen recently)  : {len(stale)}")
    lines.append("")

    def dump(title, items, cap=50):
        if not items:
            return
        lines.append(f"-- ADVISORY: {title} ({len(items)} total, showing up to {cap}) --")
        for item in items[:cap]:
            lines.append(f"    {item}")
        lines.append("")

    dump("Email addresses rejected", advisories["email_rejected"])
    dump("Invalid / no-TLD entries", advisories["invalid"])
    dump("Dropped on re-validation", revalidation_drops)
    if stale:
        dump("Stale entries (candidates for pruning)", stale)

    with open(path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return path


# =============================================================================
#  SECTION 6 -- MAIN
# =============================================================================

def main():
    """
    Run the whole build: read flags, log in to Zscaler, pull the category,
    validate, merge (accretive + aging), and write the EDL + report.
    """
    # ---- command-line options ----
    parser = argparse.ArgumentParser(
        description="Build/refresh a Palo Alto EDL from a Zscaler custom URL "
                    "category (accretive + aging merge, full validation)."
    )
    parser.add_argument("--auth", choices=["oneapi", "legacy"],
                        help="which Zscaler API framework your tenant uses")
    parser.add_argument("--category",
                        help="the Zscaler custom category name (configuredName)")
    parser.add_argument("--list", action="store_true",
                        help="list all custom categories and their IDs, then exit")
    parser.add_argument("--name",
                        help="base name for output files (defaults to --category)")
    parser.add_argument("--out", default="./edl_out",
                        help="output directory (default: ./edl_out)")
    parser.add_argument("--stale-days", type=int, default=180,
                        help="entries not seen in this many days are flagged stale (default: 180)")
    parser.add_argument("--timeout", type=int, default=30,
                        help="HTTPS timeout in seconds (default: 30)")
    parser.add_argument("--dry-run", action="store_true",
                        help="show what would happen but write nothing")
    parser.add_argument("--version", action="store_true",
                        help="print the script version and exit")
    args = parser.parse_args()

    # ---- --version short-circuit ----
    if args.version:
        print(f"zscaler_category_edl_builder.py v{__version__}")
        return

    if not args.auth:
        sys.exit("ERROR: --auth oneapi|legacy is required (or use --version).")

    # ---- log in and pull categories ----
    try:
        if args.auth == "oneapi":
            categories = get_categories_oneapi(args.timeout)
        else:
            categories = get_categories_legacy(args.timeout)
    except KeyError as missing:
        sys.exit(f"ERROR: missing environment variable {missing}. "
                 f"See the header of this script for the variables each --auth mode needs.")
    except Exception as problem:
        sys.exit(f"ERROR talking to Zscaler: {problem}")

    # ---- --list short-circuit: prove login works, show names + IDs ----
    if args.list:
        print(f"{'ID':<26}{'CONFIGURED NAME':<42}{'MEMBERS'}")
        for category in categories:
            print(f"{str(category.get('id','')):<26}"
                  f"{str(category.get('configuredName','')):<42}"
                  f"{len(collect_members(category))}")
        return

    if not args.category:
        sys.exit("ERROR: --category is required (or use --list to see the names).")

    # ---- find the requested category ----
    match = next((c for c in categories
                  if c.get("configuredName") == args.category
                  or str(c.get("id")) == args.category), None)
    if not match:
        sys.exit(f"ERROR: category '{args.category}' not found. "
                 f"Run with --list to see available custom categories.")

    name = args.name or args.category
    today = datetime.date.today().isoformat()
    raw_members = collect_members(match)

    # ---- prepare tally counters + advisory lists ----
    counters = {key: 0 for key in [
        "blank", "leading_dot_fixed", "path_stripped", "ip_accepted",
        "defang_fixed", "email_rejected", "trailing_dot_fixed", "lowercased",
        "domain_accepted", "invalid",
    ]}
    advisories = {key: [] for key in ["email_rejected", "invalid"]}

    # ---- validate today's pull ----
    today_entries = {}
    for member in raw_members:
        kind, value = classify_and_clean(member, counters, advisories)
        if kind is not None:
            today_entries[value] = kind

    # ---- load memory + RE-VALIDATE every previously-published entry ----
    if not args.dry_run:
        os.makedirs(args.out, exist_ok=True)
    state_path = os.path.join(args.out, f"{name}_state.json")
    state = load_state(state_path)

    revalidation_drops = []
    revalidated = {}
    throwaway_c = {k: 0 for k in counters}
    throwaway_a = {k: [] for k in advisories}
    for value, meta in state["entries"].items():
        kind, clean_value = classify_and_clean(value, throwaway_c, throwaway_a)
        if kind is not None and clean_value == value:
            revalidated[value] = meta
        else:
            revalidation_drops.append(value)
    state["entries"] = revalidated

    # ---- merge (count outcomes before mutating, for an honest report) ----
    known_before = set(state["entries"].keys())
    added = sum(1 for v in today_entries if v not in known_before)
    refreshed = sum(1 for v in today_entries if v in known_before)
    aged = sum(1 for v in known_before if v not in today_entries)
    state = merge_into_state(today_entries, state, today)

    # ---- compute stale entries ----
    cutoff = datetime.date.today() - datetime.timedelta(days=args.stale_days)
    stale = []
    for value, meta in state["entries"].items():
        try:
            if datetime.date.fromisoformat(meta["last_seen"]) < cutoff:
                stale.append(value)
        except Exception:
            pass

    total_domains = sum(1 for m in state["entries"].values() if m["kind"] == "domain")
    total_ips = sum(1 for m in state["entries"].values() if m["kind"] == "ip")

    # ---- write everything unless this is a dry run ----
    if args.dry_run:
        print("[DRY RUN] nothing written. Summary of what WOULD happen:")
        print(f"  category            : {args.category}")
        print(f"  raw members pulled  : {len(raw_members)}")
        print(f"  valid today         : {len(today_entries)}")
        print(f"  re-validation drops : {len(revalidation_drops)}")
        print(f"  new / refreshed     : {added} / {refreshed}")
        print(f"  aged (kept)         : {aged}")
        print(f"  published domains   : {total_domains}")
        print(f"  published ips       : {total_ips}")
        print(f"  stale (> {args.stale_days}d)     : {len(stale)}")
        return

    n_dom, n_ip = write_edls(args.out, name, state)
    save_state(state_path, state)
    report_path = write_report(args.out, name, args.category, args.auth,
                               len(raw_members), counters, advisories,
                               added, refreshed, aged, n_dom, n_ip, stale,
                               revalidation_drops)

    print(json.dumps({
        "version": __version__,
        "category": args.category,
        "auth": args.auth,
        "raw_members": len(raw_members),
        "valid_today": len(today_entries),
        "revalidation_drops": len(revalidation_drops),
        "added": added, "refreshed": refreshed, "aged": aged,
        "published_domains": n_dom, "published_ips": n_ip,
        "stale": len(stale),
        "report": report_path,
    }, indent=2))


if __name__ == "__main__":
    main()
