#!/usr/bin/env python3
"""
zscaler_category_sync.py  —  CCD Platform
Pull a Zscaler ZIA custom URL category's membership and emit it as a PAN-OS
domain EDL (and IP EDL, if the category contains IPs). Built to keep an NGFW
EDL in sync with a Zscaler-maintained custom category (e.g. CVSH-Enterprise-Allow-AI)
so the two enforcement layers share ONE source of truth.

Supports BOTH Zscaler auth frameworks (pure stdlib, no SDK required):
  --auth oneapi   OAuth2 client-credentials via Zidentity (modern, recommended)
  --auth legacy   Obfuscated-API-key admin session (tenants not yet on Zidentity)

The category membership lives in the Zscaler cloud config — it is maintained by
admins in the portal (or via API), NOT in a file. This tool is the authoritative
bridge: Zscaler category  ->  PAN-OS EDL .txt  ->  firewall pulls hourly.

Outputs (per category):
  <out>/<edl_name>.txt                      domain EDL (firewall-served)
  <out>/<edl_name>_ips.txt                  IP EDL (only if category has IP/CIDR entries)
  <out>/<edl_name>_sync_report.txt          what was pulled / cleaned / changed vs prior
  <out>/<edl_name>.set                      PAN-OS set-format EDL object + (allow|block) rule

Reuses the PAN-OS cleaning conventions from soc_edl_fetch.py (defang, lowercase,
punycode-safe, email reject, IP split).

Credentials are read from the environment — NEVER pass secrets on the CLI.
  OneAPI : ZSCALER_CLIENT_ID, ZSCALER_CLIENT_SECRET, ZSCALER_VANITY_DOMAIN, ZSCALER_CLOUD(optional)
  Legacy : ZIA_API_KEY, ZIA_USERNAME, ZIA_PASSWORD, ZIA_CLOUD (e.g. zscalerthree.net)

Usage:
  export ZSCALER_CLIENT_ID=... ZSCALER_CLIENT_SECRET=... ZSCALER_VANITY_DOMAIN=cvshealth
  python zscaler_category_sync.py --auth oneapi --category CVSH-Enterprise-Allow-AI \
      --out ./edl_out --edl-name CVSH-Enterprise-Allow-AI --rule-action allow

  export ZIA_API_KEY=... ZIA_USERNAME=svc@cvshealth.com ZIA_PASSWORD=... ZIA_CLOUD=zscalerthree.net
  python zscaler_category_sync.py --auth legacy --category CVSH-Enterprise-Allow-AI --out ./edl_out

  python zscaler_category_sync.py --auth legacy --list   # list all custom categories + IDs, then exit
"""
from __future__ import annotations
import argparse, json, os, sys, time, re, ipaddress, datetime, ssl
import urllib.request, urllib.parse, urllib.error, http.cookiejar

__version__ = "1.0.0"

# ---- PAN-OS cleaning (aligned with soc_edl_fetch.py) ----
DOMAIN_RE = re.compile(r"^(?=.{1,253}$)(?!-)([A-Za-z0-9-]{1,63}\.)+([A-Za-z]{2,63}|xn--[A-Za-z0-9]{2,59})$")
DEFANG_RE = re.compile(r"\[\.\]|\(\.\)|\[dot\]", re.I)


def is_ip_or_cidr(tok):
    try:
        ipaddress.ip_network(tok, strict=False) if "/" in tok else ipaddress.ip_address(tok)
        return True
    except ValueError:
        return False


def clean_entry(raw):
    """Return ('domain'|'ip'|None, value)."""
    s = raw.strip()
    if not s:
        return None, None
    # Zscaler category URLs may be like  ".chatgpt.com"  or  "chatgpt.com/path"
    s = s.lstrip(".")
    s = s.split("/")[0]            # strip any path component
    if is_ip_or_cidr(s):
        return "ip", s
    if DEFANG_RE.search(s):
        s = DEFANG_RE.sub(".", s)
    if "@" in s:
        return None, None
    s = s.rstrip(".").lower()
    if "." in s and DOMAIN_RE.match(s):
        return "domain", s
    return None, None


# ---------------------------------------------------------------------------
# OneAPI (OAuth2 client-credentials via Zidentity)
# ---------------------------------------------------------------------------
def oneapi_token(client_id, client_secret, vanity_domain, cloud=None):
    base = f"https://{vanity_domain}.zslogin.net"
    if cloud and cloud not in ("production", "prod"):
        base = f"https://{vanity_domain}.zslogin{('.' + cloud) if cloud else ''}.net"
    url = f"{base}/oauth2/v1/token"
    data = urllib.parse.urlencode({
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "audience": "https://api.zscaler.com",
    }).encode()
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=30, context=ssl.create_default_context()) as r:
        tok = json.load(r)
    return tok["access_token"]


def oneapi_get(api_base, token, path):
    req = urllib.request.Request(api_base + path,
                                 headers={"Authorization": f"Bearer {token}", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=30, context=ssl.create_default_context()) as r:
        return json.load(r)


# ---------------------------------------------------------------------------
# Legacy (obfuscated API key admin session)  — algorithm per Zscaler docs
# ---------------------------------------------------------------------------
def obfuscate_api_key(seed):
    now = int(time.time() * 1000)
    n = str(now)[-6:]
    r = str(int(n) >> 1).zfill(6)
    key = ""
    for ch in n:
        key += seed[int(ch)]
    for ch in r:
        key += seed[int(ch) + 2]
    return now, key


def legacy_session(api_key, username, password, cloud):
    base = f"https://zsapi.{cloud}/api/v1" if not cloud.startswith("http") else cloud
    ts, obf = obfuscate_api_key(api_key)
    payload = json.dumps({"apiKey": obf, "username": username,
                          "password": password, "timestamp": ts}).encode()
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    req = urllib.request.Request(base + "/authenticatedSession", data=payload,
                                 headers={"Content-Type": "application/json", "Cache-Control": "no-cache"})
    opener.open(req, timeout=30)
    return base, opener


def legacy_get(base, opener, path):
    req = urllib.request.Request(base + path, headers={"Accept": "application/json"})
    with opener.open(req, timeout=30) as r:
        return json.load(r)


# ---------------------------------------------------------------------------
def fetch_categories(args):
    """Return list of category dicts (with id, configuredName, urls, dbCategorizedUrls)."""
    if args.auth == "oneapi":
        cid = os.environ["ZSCALER_CLIENT_ID"]; csec = os.environ["ZSCALER_CLIENT_SECRET"]
        vanity = os.environ["ZSCALER_VANITY_DOMAIN"]; cloud = os.environ.get("ZSCALER_CLOUD")
        token = oneapi_token(cid, csec, vanity, cloud)
        api_base = "https://api.zsapi.net/zia/api/v1"  # OneAPI ZIA base
        return oneapi_get(api_base, token, "/urlCategories?customOnly=true")
    else:
        key = os.environ["ZIA_API_KEY"]; user = os.environ["ZIA_USERNAME"]
        pw = os.environ["ZIA_PASSWORD"]; cloud = os.environ.get("ZIA_CLOUD", "zscalerthree.net")
        base, opener = legacy_session(key, user, pw, cloud)
        try:
            return legacy_get(base, opener, "/urlCategories?customOnly=true")
        finally:
            try:
                opener.open(urllib.request.Request(base + "/authenticatedSession", method="DELETE"), timeout=15)
            except Exception:
                pass


def category_members(cat):
    """Collect URL/IP members from a Zscaler category object across its list fields."""
    members = []
    for field in ("urls", "dbCategorizedUrls", "ipRanges", "ipRangesRetainingParentCategory"):
        v = cat.get(field)
        if isinstance(v, list):
            members.extend(v)
    return members


def emit_set(edl_name, edl_host, n_dom, n_ip, action):
    dom_obj = f"EDL-{edl_name}"
    ip_obj = f"EDL-{edl_name}-IPS"
    L = [f"# Zscaler category sync — {edl_name}", f"#VERSION={__version__}",
         f"#SYNCED_FROM=Zscaler custom URL category", ""]
    L.append("# ===== EDL objects =====")
    if n_dom:
        L.append(f'set external-list {dom_obj} type domain recurring hourly url "{edl_host}/{edl_name}.txt"')
    if n_ip:
        L.append(f'set external-list {ip_obj} type ip recurring hourly url "{edl_host}/{edl_name}_ips.txt"')
    L.append("")
    if action == "allow":
        L.append("# ===== ALLOW rule (sanctioned) — must sit ABOVE any AI/category block =====")
        L.append(f"set rulebase security rules Allow-{edl_name} from trust to untrust source any "
                 f"destination any category {dom_obj} application [ ssl web-browsing ] "
                 f"service application-default action allow")
        L.append(f"set rulebase security rules Allow-{edl_name} profile-setting group SOC-DLP-Inspect")
        L.append(f"set rulebase security rules Allow-{edl_name} log-end yes")
        L.append("# NOTE: DLP profile attached so sanctioned traffic is allowed-but-inspected.")
    else:
        L.append("# ===== BLOCK rule =====")
        if n_ip:
            L.append(f"set rulebase security rules Block-{edl_name}-IP from any to any source any "
                     f"destination {ip_obj} application any service any action deny")
        L.append(f"set rulebase security rules Block-{edl_name}-DOM from any to any source any "
                 f"destination any category {dom_obj} application any service any action deny")
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser(description="Sync a Zscaler ZIA custom URL category to a PAN-OS EDL.")
    ap.add_argument("--auth", choices=["oneapi", "legacy"], required=True)
    ap.add_argument("--category", help="Zscaler custom category configuredName (e.g. CVSH-Enterprise-Allow-AI)")
    ap.add_argument("--list", action="store_true", help="list all custom categories + IDs and exit")
    ap.add_argument("--out", default="./edl_out")
    ap.add_argument("--edl-name", help="output EDL base name (defaults to --category)")
    ap.add_argument("--edl-host", default="https://edl.cvshealth.internal/ccd")
    ap.add_argument("--rule-action", choices=["allow", "block"], default="allow",
                    help="emit an allow rule (sanctioned list) or block rule (default: allow)")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    try:
        cats = fetch_categories(args)
    except urllib.error.HTTPError as e:
        sys.exit(f"ERROR: Zscaler API HTTP {e.code} — {e.reason}. Check credentials/role.")
    except KeyError as e:
        sys.exit(f"ERROR: missing environment variable {e}. See header for required vars.")
    except Exception as e:
        sys.exit(f"ERROR contacting Zscaler: {e}")

    if args.list:
        print(f"{'ID':<26}{'CONFIGURED NAME':<40}{'MEMBERS'}")
        for c in cats:
            print(f"{str(c.get('id','')):<26}{str(c.get('configuredName','')):<40}{len(category_members(c))}")
        return

    if not args.category:
        sys.exit("ERROR: --category required (or use --list).")
    match = next((c for c in cats if c.get("configuredName") == args.category
                  or str(c.get("id")) == args.category), None)
    if not match:
        sys.exit(f"ERROR: category '{args.category}' not found. Run --list to see available custom categories.")

    edl_name = args.edl_name or args.category
    domains, ips, skipped = [], [], []
    for m in category_members(match):
        kind, val = clean_entry(m)
        if kind == "domain":
            domains.append(val)
        elif kind == "ip":
            ips.append(val)
        else:
            skipped.append(m)
    domains = sorted(set(domains)); ips = sorted(set(ips))

    stamp = datetime.date.today().strftime("%Y-%m-%d %H:%M")
    report = [
        f"Zscaler Category Sync Report",
        f"============================",
        f"Category       : {args.category}  (id={match.get('id')})",
        f"Auth framework : {args.auth}",
        f"Synced at      : {stamp}",
        f"Raw members    : {len(category_members(match))}",
        f"Domain EDL     : {len(domains)}",
        f"IP EDL         : {len(ips)}",
        f"Skipped (invalid for PAN-OS EDL): {len(skipped)}",
    ]
    if skipped:
        report.append("  " + ", ".join(skipped[:30]) + (" ..." if len(skipped) > 30 else ""))

    if args.dry_run:
        print("\n".join(report)); print("\n[dry-run] no files written."); return

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, f"{edl_name}.txt"), "w") as f:
        f.write(f"# {edl_name} — synced from Zscaler category {args.category} at {stamp}\n")
        f.write("\n".join(domains) + ("\n" if domains else ""))
    if ips:
        with open(os.path.join(args.out, f"{edl_name}_ips.txt"), "w") as f:
            f.write("\n".join(ips) + "\n")
    with open(os.path.join(args.out, f"{edl_name}_sync_report.txt"), "w") as f:
        f.write("\n".join(report) + "\n")
    with open(os.path.join(args.out, f"{edl_name}.set"), "w") as f:
        f.write(emit_set(edl_name, args.edl_host, len(domains), len(ips), args.rule_action))

    print(json.dumps({"version": __version__, "category": args.category,
                      "domains": len(domains), "ips": len(ips), "skipped": len(skipped),
                      "out": args.out}, indent=2))


if __name__ == "__main__":
    main()
