#!/usr/bin/env python3
"""
soc_edl_fetch.py  —  CCD Platform
Fetch a SOC threat feed (URL or local file), parse + clean it to PAN-OS EDL
requirements, split into domain and IP EDLs, and emit the set-format CLI for the
EDL objects and the block rules that reference them.

Cleaning behavior reproduces edl_cleaning_report.txt conventions:
  REJECT : blank, metadata header lines, ?-prefixed artifacts, bullet/hash-mixed,
           SHA-256/SHA-1 hashes, no-TLD tokens, partial-IP octets, unfixable
           whitespace, bare-TLD (.ru style — advisory), duplicates.
  AUTOFIX: strip trailing dot, lowercase, collapse internal spaces in dotted names.
  SPLIT  : valid IPv4/IPv6 + CIDR -> ip_edl ; valid FQDN -> domain_edl.

PAN-OS rules emitted (block):
  set external-list <DOM_NAME>  type domain ...
  set external-list <IP_NAME>   type ip ...
  set security rules <rule> ... source any destination-edl-or-category ... action deny
  (DNS-domain EDLs are referenced via an Anti-Spyware / DNS Security external list;
   IP EDLs are referenced directly as destination address in a deny rule.)

Versioning: __version__ MAJOR.MINOR.PATCH; outputs carry #VERSION + date stamp.
Governance: --dry-run prints the cleaning report only (no writes). Always review the
advisory output before promoting a feed.

Usage:
  python soc_edl_fetch.py --url https://soc.example/feed.txt --out ./edl_out
  python soc_edl_fetch.py --file domain_blocklist.txt --out ./edl_out --name SOC-CTI
  python soc_edl_fetch.py --url <url> --dry-run
"""
from __future__ import annotations
import argparse, ipaddress, json, os, re, sys, datetime, urllib.request, ssl

__version__ = "1.0.0"

# Accepts punycode/IDN labels (xn--...) in both labels and TLD position.
DOMAIN_RE = re.compile(r"^(?=.{1,253}$)(?!-)([A-Za-z0-9-]{1,63}\.)+([A-Za-z]{2,63}|xn--[A-Za-z0-9]{2,59})$")
DEFANG_RE = re.compile(r"\[\.\]|\(\.\)|\[dot\]", re.I)
SHA_RE = re.compile(r"^[A-Fa-f0-9]{40}$|^[A-Fa-f0-9]{64}$")
PARTIAL_IP_RE = re.compile(r"^\d{1,3}\.\d{1,3}$")  # e.g. 16.252
LEADING_JUNK = re.compile(r"^[?#•*\-\s]+")


def fetch(url: str, timeout: int = 30) -> str:
    ctx = ssl.create_default_context()
    req = urllib.request.Request(url, headers={"User-Agent": "CCD-SOC-EDL/%s" % __version__})
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.read().decode("utf-8", errors="replace")


def is_ip_or_cidr(tok: str):
    try:
        if "/" in tok:
            ipaddress.ip_network(tok, strict=False); return True
        ipaddress.ip_address(tok); return True
    except ValueError:
        return False


def clean(raw: str):
    report = {k: 0 for k in [
        "blank", "metadata_header", "q_prefixed", "bullet_hash_mixed", "sha_hash",
        "no_tld", "partial_ip", "unfixable_ws", "bare_tld", "duplicates",
        "trailing_dot_fixed", "lowercased", "space_collapsed", "defanged_fixed", "email_rejected"]}
    advisories = {"q_prefixed": [], "no_tld": [], "bare_tld": [], "whitespace_phrase": []}
    domains, ips = [], []
    seen = set()

    for line in raw.splitlines():
        s = line.strip()
        if not s:
            report["blank"] += 1; continue
        if s.lower().startswith(("type=", "#meta", "# meta")) or s.startswith("#"):
            report["metadata_header"] += 1; continue
        # IP / CIDR first (before domain heuristics)
        if is_ip_or_cidr(s):
            if s not in seen:
                seen.add(s); ips.append(s)
            else:
                report["duplicates"] += 1
            continue
        # ?-prefixed diff/corruption artifacts
        if s.startswith("?"):
            report["q_prefixed"] += 1; advisories["q_prefixed"].append(s); continue
        # bullet/hash mixed
        if re.match(r"^[•*\-]+\s*[#]", s) or ("•" in s and "#" in s):
            report["bullet_hash_mixed"] += 1; continue
        # SHA hashes
        if SHA_RE.match(s):
            report["sha_hash"] += 1; continue
        # partial IP octets
        if PARTIAL_IP_RE.match(s):
            report["partial_ip"] += 1; continue
        # phrase with internal spaces that is NOT a dotted-name spacing artifact
        if " " in s:
            collapsed = s.replace(" ", "")
            # 'cwshealth . com' -> cwshealth.com  (dot-spacing artifact)
            if re.match(r"^[A-Za-z0-9.-]+\s*\.\s*[A-Za-z0-9.-]+$", s) and DOMAIN_RE.match(collapsed):
                report["space_collapsed"] += 1
                s = collapsed
            else:
                report["unfixable_ws"] += 1
                advisories["whitespace_phrase"].append(s); continue
        # strip leading junk chars
        s = LEADING_JUNK.sub("", s)
        # re-fang defanged IOCs:  armiarm[.]shop -> armiarm.shop
        if DEFANG_RE.search(s):
            s = DEFANG_RE.sub(".", s)
            report["defanged_fixed"] = report.get("defanged_fixed", 0) + 1
        # email addresses are not domain EDL entries
        if "@" in s:
            report["email_rejected"] = report.get("email_rejected", 0) + 1
            advisories.setdefault("email", []).append(line.strip()); continue
        # trailing dot
        if s.endswith("."):
            stripped = s.rstrip(".")
            # bare TLD like '.ru' -> after strip becomes 'ru' (no dot) -> bare_tld advisory
            if "." not in stripped:
                report["bare_tld"] += 1; advisories["bare_tld"].append(line.strip()); continue
            report["trailing_dot_fixed"] += 1; s = stripped
        # bare-TLD form '.ru'
        if s.startswith(".") and s.count(".") == 1:
            report["bare_tld"] += 1; advisories["bare_tld"].append(s); continue
        # lowercase
        low = s.lower()
        if low != s:
            report["lowercased"] += 1; s = low
        else:
            s = low
        # no TLD (no dot, or not a valid domain)
        if "." not in s or not DOMAIN_RE.match(s):
            report["no_tld"] += 1; advisories["no_tld"].append(line.strip()); continue
        # accept domain
        if s not in seen:
            seen.add(s); domains.append(s)
        else:
            report["duplicates"] += 1

    return domains, ips, report, advisories


def render_report(report, advisories, n_in, n_dom, n_ip, src):
    removed = (report["blank"] + report["metadata_header"] + report["q_prefixed"]
               + report["bullet_hash_mixed"] + report["sha_hash"] + report["no_tld"]
               + report["partial_ip"] + report["unfixable_ws"] + report["bare_tld"]
               + report["duplicates"] + report.get("email_rejected", 0))
    L = []
    L.append("PAN-OS EDL Cleaning Report")
    L.append("=" * 26)
    L.append(f"Generated from : {src}")
    L.append(f"Total input lines   : {n_in:6}")
    L.append("")
    L.append("\u2500\u2500 REJECTED \u2500\u2500")
    L.append(f"  Blank / empty              : {report['blank']:5}")
    L.append(f"  Metadata header            : {report['metadata_header']:5}")
    L.append(f"  ?-prefixed invalid entries : {report['q_prefixed']:5}")
    L.append(f"  Bullet/hash mixed lines    : {report['bullet_hash_mixed']:5}")
    L.append(f"  SHA-256/SHA-1 hashes       : {report['sha_hash']:5}")
    L.append(f"  No-TLD (no dot, invalid)   : {report['no_tld']:5}")
    L.append(f"  Partial IP octets          : {report['partial_ip']:5}")
    L.append(f"  Unfixable whitespace       : {report['unfixable_ws']:5}")
    L.append(f"  Bare TLD entries           : {report['bare_tld']:5}")
    L.append(f"  Duplicates removed         : {report['duplicates']:5}")
    L.append(f"  Email addresses rejected   : {report.get('email_rejected',0):5}")
    L.append(f"  Total entries removed      : {removed:5}")
    L.append("")
    L.append("\u2500\u2500 AUTO-FIXED \u2500\u2500")
    L.append(f"  Trailing dot stripped      : {report['trailing_dot_fixed']:5}")
    L.append(f"  Lowercase normalised       : {report['lowercased']:5}")
    L.append(f"  Space-collapsed (dot only) : {report['space_collapsed']:5}")
    L.append(f"  Defanged IOC re-fanged     : {report.get('defanged_fixed',0):5}   (e.g. armiarm[.]shop \u2192 armiarm.shop)")
    L.append("")
    L.append("\u2500\u2500 OUTPUT SUMMARY \u2500\u2500")
    L.append(f"  Domain EDL entries         : {n_dom:6}   \u2192 domain_edl.txt")
    L.append(f"  IP EDL entries             : {n_ip:6}   \u2192 ip_edl.txt")
    if advisories["bare_tld"]:
        L.append("")
        L.append("\u2500\u2500 ADVISORY \u2014 Bare TLD entries (NOT valid in PAN-OS domain EDL) \u2500\u2500")
        L.append("  Use a custom URL category with '*.tld' in a Security Policy instead.")
        for x in advisories["bare_tld"]:
            L.append(f"    {x}")
    if advisories["q_prefixed"]:
        L.append("")
        L.append(f"\u2500\u2500 ADVISORY \u2014 Rejected ?-prefixed entries ({len(advisories['q_prefixed'])}) \u2500\u2500")
        L.append("  Likely diff/corruption artifacts \u2014 verify if any were intended valid.")
        for x in advisories["q_prefixed"]:
            L.append(f"    {x}")
    if advisories["whitespace_phrase"]:
        L.append("")
        L.append(f"\u2500\u2500 ADVISORY \u2014 Rejected whitespace/phrase entries ({len(advisories['whitespace_phrase'])}) \u2500\u2500")
        for x in advisories["whitespace_phrase"]:
            L.append(f"    {x}")
    if advisories["no_tld"]:
        L.append("")
        L.append(f"\u2500\u2500 ADVISORY \u2014 No-TLD entries removed ({len(advisories['no_tld'])}) \u2500\u2500")
        for x in advisories["no_tld"]:
            L.append(f"    {x}")
    return "\n".join(L)


def emit_set(name, edl_host, dom_file, ip_file, n_dom, n_ip):
    dom_obj = f"EDL-{name}-DOMAINS"
    ip_obj = f"EDL-{name}-IPS"
    L = []
    L.append(f"# SOC threat-block EDLs — {name}")
    L.append(f"#VERSION={__version__}")
    L.append("")
    L.append("# ===== EDL objects =====")
    if n_dom:
        L.append(f'set external-list {dom_obj} type domain recurring hourly url "{edl_host}/{dom_file}"')
    if n_ip:
        L.append(f'set external-list {ip_obj} type ip recurring hourly url "{edl_host}/{ip_file}"')
    L.append("")
    L.append("# ===== Block rules =====")
    if n_ip:
        L.append(f"set rulebase security rules SOC-Block-IP-{name} from any to any source any "
                 f"destination {ip_obj} application any service any action deny")
        L.append(f"set rulebase security rules SOC-Block-IP-{name} log-end yes")
    if n_dom:
        # domain EDL is consumed by an Anti-Spyware / DNS Security profile external list,
        # OR as a custom-URL-category match in a URL Filtering deny rule. Emit both options.
        L.append(f"# Domain EDL option A — DNS Security / Anti-Spyware external dynamic list:")
        L.append(f"set profiles spyware SOC-{name} botnet-domains lists {dom_obj} action sinkhole")
        L.append(f"# Domain EDL option B — URL Filtering deny via custom category referencing the EDL:")
        L.append(f"set rulebase security rules SOC-Block-DOM-{name} from any to any source any "
                 f"destination any category {dom_obj} application any service any action deny")
        L.append(f"set rulebase security rules SOC-Block-DOM-{name} log-end yes")
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser(description="Fetch + clean a SOC threat feed into PAN-OS domain/IP EDLs and block rules.")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--url", help="SOC feed URL")
    g.add_argument("--file", help="local feed file")
    ap.add_argument("--out", default="./edl_out", help="output directory")
    ap.add_argument("--name", default="SOC-CTI", help="EDL base name (used in object + filenames)")
    ap.add_argument("--edl-host", default="https://edl.cvshealth.internal/ccd", help="base URL where EDL files are served to the firewall")
    ap.add_argument("--timeout", type=int, default=30)
    ap.add_argument("--dry-run", action="store_true", help="print cleaning report only; write nothing")
    args = ap.parse_args()

    src = args.url or args.file
    try:
        raw = fetch(args.url, args.timeout) if args.url else open(args.file, encoding="utf-8", errors="replace").read()
    except Exception as e:
        sys.exit(f"ERROR fetching feed: {e}")

    n_in = len(raw.splitlines())
    domains, ips, report, advisories = clean(raw)
    rpt = render_report(report, advisories, n_in, len(domains), len(ips), src)

    if args.dry_run:
        print(rpt)
        print("\n[dry-run] no files written.")
        return

    os.makedirs(args.out, exist_ok=True)
    stamp = datetime.date.today().strftime("%Y%m%d")
    dom_file = f"{args.name}_domain_edl_v{stamp}.txt"
    ip_file = f"{args.name}_ip_edl_v{stamp}.txt"
    with open(os.path.join(args.out, dom_file), "w") as f:
        f.write("\n".join(domains) + ("\n" if domains else ""))
    with open(os.path.join(args.out, ip_file), "w") as f:
        f.write("\n".join(ips) + ("\n" if ips else ""))
    with open(os.path.join(args.out, f"{args.name}_cleaning_report_v{stamp}.txt"), "w") as f:
        f.write(rpt + "\n")
    with open(os.path.join(args.out, f"{args.name}_edl_rules_v{stamp}.set"), "w") as f:
        f.write(emit_set(args.name, args.edl_host, dom_file, ip_file, len(domains), len(ips)))

    print(json.dumps({
        "version": __version__, "source": src, "input_lines": n_in,
        "domain_edl": len(domains), "ip_edl": len(ips),
        "removed": n_in - len(domains) - len(ips),
        "out": args.out, "name": args.name,
    }, indent=2))


if __name__ == "__main__":
    main()
