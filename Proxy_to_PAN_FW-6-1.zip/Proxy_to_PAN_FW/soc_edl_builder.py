#!/usr/bin/env python3
# =============================================================================
#  soc_edl_builder.py
# =============================================================================
#  WHAT THIS SCRIPT DOES (read this first)
#  -----------------------------------------------------------------------------
#  A SOC (Security Operations Center) publishes a list of "bad" domains and IP
#  addresses that we want our Palo Alto firewall to BLOCK. That list is usually
#  typed/curated by humans, so it is messy: bracketed "defanged" entries like
#  evil[.]com, stray spaces, comments, email addresses, file hashes, blank
#  lines, duplicates, and so on.
#
#  A Palo Alto "EDL" (External Dynamic List) is just a plain text file, one
#  entry per line, that the firewall downloads on a schedule. The firewall is
#  STRICT: if even a few lines are malformed it can reject the whole list. So
#  our job is to take the messy human list and produce a perfectly clean EDL.
#
#  HOW IT WORKS (the "accretive + aging" model)
#  -----------------------------------------------------------------------------
#  Every time this script runs it produces a NEW version that is the COMBINATION
#  of (a) everything we published last time and (b) everything valid in today's
#  fresh feed. We never silently drop a known-bad entry just because it fell out
#  of today's feed. Instead:
#     * first_seen  = the date we first ever saw this entry
#     * last_seen   = the most recent date the entry appeared in a source feed
#  Entries that stop showing up keep living in the list but their last_seen
#  stops advancing, so later you can prune anything "stale" (not seen in N days).
#
#  SAFETY GUARANTEES (why you can trust the output)
#  -----------------------------------------------------------------------------
#  1. EVERY entry is re-validated every run -- even ones we published before --
#     so an entry that somehow became invalid is caught and removed.
#  2. Malformed entries are NEVER written to the EDL. They are bypassed and
#     listed in a report so a human can look at them.
#  3. The final list is de-duplicated and hygiene-checked before writing.
#  4. Domains and IPs are split into two separate EDL files, because Palo Alto
#     uses a different EDL "type" for each.
#
#  WHAT YOU GET AFTER A RUN (output files)
#  -----------------------------------------------------------------------------
#     <name>_domains.txt          <- clean domain EDL  (firewall downloads this)
#     <name>_ips.txt              <- clean IP EDL       (firewall downloads this)
#     <name>_state.json           <- the date-tracking memory (DO NOT delete)
#     <name>_report_<stamp>.txt   <- human-readable "what happened" report
#
#  HOW TO RUN IT (examples)
#  -----------------------------------------------------------------------------
#     # Pull today's feed from a URL and merge it into the published EDL:
#     python soc_edl_builder.py --url https://soc.example/blocklist.txt --name SOC-CTI
#
#     # Use a local file instead of a URL:
#     python soc_edl_builder.py --file todays_feed.txt --name SOC-CTI
#
#     # See what WOULD happen without writing anything (safe preview):
#     python soc_edl_builder.py --file todays_feed.txt --name SOC-CTI --dry-run
#
#     # Just print the version and exit:
#     python soc_edl_builder.py --version
#
#  This script uses ONLY the Python standard library. Nothing to install.
# =============================================================================

from __future__ import annotations          # lets us use modern type hints on older Python
import argparse        # parses the command-line flags like --url and --name
import datetime        # for today's date (used in first_seen / last_seen)
import ipaddress       # validates IP addresses and CIDR ranges correctly
import json            # reads/writes the state file that remembers dates
import os              # builds file paths and checks if files exist
import re              # regular expressions, used to validate domain names
import ssl             # secure HTTPS connection when downloading a feed
import sys             # lets us exit with an error code the OS can see
import urllib.request  # downloads the feed from a URL (standard library)

# -----------------------------------------------------------------------------
#  VERSION
#  CCD rule: __version__ is the ONE canonical version variable. Format is
#  MAJOR.MINOR.PATCH. Bump PATCH for bug fixes, MINOR for new features, MAJOR
#  for anything that breaks how the script is used.
# -----------------------------------------------------------------------------
__version__ = "1.0.0"


# =============================================================================
#  SECTION 1 -- VALIDATION RULES (the heart of the data-quality checking)
# =============================================================================
#  These patterns and helpers decide whether a single line from the feed is a
#  valid domain, a valid IP, or garbage. Everything that protects the EDL from
#  bad data lives in this section.
# -----------------------------------------------------------------------------

# A domain name like "mail.evil-site.co.uk".
#   (?=.{1,253}$)   -> the whole name must be 1 to 253 characters (DNS limit)
#   (?!-)           -> a label may not START with a hyphen
#   [A-Za-z0-9-]{1,63}\.  -> one "label" (up to 63 chars) followed by a dot,
#                            repeated one or more times
#   [A-Za-z]{2,63}  -> the final part (the TLD) is letters only, e.g. "com"
#   xn--...         -> OR a punycode/IDN TLD like "xn--p1ai" (Russian .рф etc.)
# We accept punycode because international domains are legitimate and common in
# threat feeds; rejecting them would drop real bad domains.
DOMAIN_PATTERN = re.compile(
    r"^(?=.{1,253}$)(?!-)([A-Za-z0-9-]{1,63}\.)+([A-Za-z]{2,63}|xn--[A-Za-z0-9]{2,59})$"
)

# "Defanging" is when an analyst writes evil[.]com or evil(.)com or evil[dot]com
# so the bad domain isn't clickable in an email/report. We must turn it back
# into a real dot before the firewall can use it.
DEFANG_PATTERN = re.compile(r"\[\.\]|\(\.\)|\[dot\]", re.IGNORECASE)

# A SHA-1 (40 hex chars) or SHA-256 (64 hex chars) file hash. These sometimes
# get pasted into a blocklist by mistake. They are NOT domains or IPs, so we
# reject them (the firewall EDL cannot use file hashes).
HASH_PATTERN = re.compile(r"^[A-Fa-f0-9]{40}$|^[A-Fa-f0-9]{64}$")

# A partial IP like "16.252" (someone fat-fingered or truncated an address).
# Two numbers separated by a dot, nothing else. Caught so it doesn't sneak
# through as a "domain".
PARTIAL_IP_PATTERN = re.compile(r"^\d{1,3}\.\d{1,3}$")


def looks_like_ip_or_cidr(token: str) -> bool:
    """
    Decide whether a piece of text is a valid IP address or CIDR range.

    WHAT IT DOES
    ------------
    Returns True for things like "8.8.8.8", "10.0.0.0/8", or an IPv6 address.
    Returns False for anything the ipaddress library can't parse.

    WHY WE NEED IT
    --------------
    We must send IPs to the IP EDL and domains to the domain EDL. This is the
    test that tells the two apart. We let Python's battle-tested 'ipaddress'
    library make the call instead of writing our own fragile pattern.

    PARAMETERS
    ----------
    token : str
        One cleaned-up piece of text from the feed (no surrounding spaces).

    RETURNS
    -------
    bool
        True if it is a valid IP or CIDR, False otherwise.
    """
    try:
        # If there's a slash it's a range (CIDR) like 192.168.0.0/24...
        if "/" in token:
            ipaddress.ip_network(token, strict=False)
        # ...otherwise it's a single address like 192.168.0.1
        else:
            ipaddress.ip_address(token)
        return True
    except ValueError:
        # ipaddress raises ValueError when the text is not a real IP/CIDR.
        return False


def classify_and_clean(raw_line: str, counters: dict, advisories: dict):
    """
    Take ONE raw line from a feed and decide what it is.

    WHAT IT DOES
    ------------
    This is the single most important function in the script. It looks at one
    line of human-entered text and returns a (kind, value) pair where 'kind' is
    one of:
        "domain"  -> value is a clean domain ready for the domain EDL
        "ip"      -> value is a clean IP/CIDR ready for the IP EDL
        None      -> the line is garbage; value is None and it was reported

    Along the way it AUTO-FIXES the safe, common mistakes (defanging, upper-case,
    stray dots/spaces) and REJECTS everything it cannot trust, recording each
    decision in 'counters' (for totals) and 'advisories' (for the detailed list
    a human reviews).

    WHY IT WORKS THIS WAY
    ---------------------
    Order matters. We check the cheap, unambiguous rejections first (blank,
    comment, hash), then auto-fix, then finally validate as IP or domain. We
    NEVER guess: if a line doesn't cleanly match a known-good shape, it is
    rejected, because letting one bad line through can make Palo Alto reject the
    entire EDL.

    PARAMETERS
    ----------
    raw_line : str
        The exact line as it came from the feed, including any whitespace.
    counters : dict
        A running tally of how many lines fell into each category. Mutated here.
    advisories : dict
        Lists of the actual rejected/odd values, grouped by reason, so a human
        can eyeball them later. Mutated here.

    RETURNS
    -------
    tuple(str|None, str|None)
        ("domain", value) or ("ip", value) or (None, None).
    """
    # ---- Step 1: strip surrounding whitespace ----
    text = raw_line.strip()

    # ---- Step 2: drop blank lines ----
    if text == "":
        counters["blank"] += 1
        return None, None

    # ---- Step 3: drop comment / metadata lines ----
    # Feeds often start lines with '#' (comments) or 'type=' style metadata.
    if text.startswith("#") or text.lower().startswith("type="):
        counters["comment_or_metadata"] += 1
        return None, None

    # ---- Step 4: check for an IP or CIDR BEFORE domain logic ----
    # We do this early because an IP has dots too and we don't want the domain
    # rules to mis-handle it.
    if looks_like_ip_or_cidr(text):
        counters["ip_accepted"] += 1
        return "ip", text

    # ---- Step 5: reject SHA hashes (can't go in a domain/IP EDL) ----
    if HASH_PATTERN.match(text):
        counters["sha_hash"] += 1
        return None, None

    # ---- Step 6: reject partial IPs like "16.252" ----
    if PARTIAL_IP_PATTERN.match(text):
        counters["partial_ip"] += 1
        advisories["partial_ip"].append(text)
        return None, None

    # ---- Step 7: reject "?-prefixed" diff/corruption artifacts ----
    # Lines like "?evil.com" come from copy-pasting a diff or a corrupted feed.
    if text.startswith("?"):
        counters["question_prefixed"] += 1
        advisories["question_prefixed"].append(text)
        return None, None

    # ---- Step 8: AUTO-FIX defanging:  evil[.]com -> evil.com ----
    if DEFANG_PATTERN.search(text):
        text = DEFANG_PATTERN.sub(".", text)
        counters["defang_fixed"] += 1

    # ---- Step 9: reject email addresses (they contain '@', not valid here) ----
    if "@" in text:
        counters["email_rejected"] += 1
        advisories["email_rejected"].append(raw_line.strip())
        return None, None

    # ---- Step 10: AUTO-FIX a "dotted name with spaces" artifact ----
    # Sometimes a feed has "evil . com" (spaces around the dot). If removing the
    # spaces produces a valid domain, fix it. Otherwise it's an unfixable phrase.
    if " " in text:
        collapsed = text.replace(" ", "")
        if DOMAIN_PATTERN.match(collapsed):
            text = collapsed
            counters["space_collapsed"] += 1
        else:
            counters["unfixable_whitespace"] += 1
            advisories["unfixable_whitespace"].append(raw_line.strip())
            return None, None

    # ---- Step 11: strip a URL path if present:  evil.com/login -> evil.com ----
    # An EDL matches hostnames, not full URLs, so drop anything after the first
    # slash.
    if "/" in text:
        text = text.split("/")[0]

    # ---- Step 12: AUTO-FIX a trailing dot:  evil.com.  -> evil.com ----
    if text.endswith("."):
        text = text.rstrip(".")
        counters["trailing_dot_fixed"] += 1

    # ---- Step 13: reject a bare TLD like ".ru" (not allowed in a domain EDL) --
    # PAN-OS cannot block a whole TLD via a domain EDL; that needs a URL category
    # rule instead, so we flag it for the human and reject it here.
    if text.startswith("."):
        counters["bare_tld"] += 1
        advisories["bare_tld"].append(raw_line.strip())
        return None, None

    # ---- Step 14: AUTO-FIX upper-case:  EVIL.COM -> evil.com ----
    lowered = text.lower()
    if lowered != text:
        counters["lowercased"] += 1
    text = lowered

    # ---- Step 15: FINAL domain validation ----
    # If after all fixes it still isn't a valid domain shape, reject it. This
    # catches truncated TLDs ("evil.c"), underscores, and other junk.
    if "." in text and DOMAIN_PATTERN.match(text):
        counters["domain_accepted"] += 1
        return "domain", text

    counters["no_tld_or_invalid"] += 1
    advisories["no_tld_or_invalid"].append(raw_line.strip())
    return None, None


# =============================================================================
#  SECTION 2 -- READING THE FEED (from a URL or a local file)
# =============================================================================

def load_feed(url: str | None, file_path: str | None, timeout: int) -> str:
    """
    Get the raw text of today's feed, from either a URL or a local file.

    WHAT IT DOES
    ------------
    If a URL was given, downloads it over HTTPS (with normal certificate
    checking). If a file was given instead, reads that file. Returns the raw
    text exactly as received -- cleaning happens later.

    WHY IT WORKS THIS WAY
    ---------------------
    Separating "get the bytes" from "clean the bytes" keeps each job simple and
    makes the script easy to test with a local file before pointing it at a
    real SOC URL.

    PARAMETERS
    ----------
    url : str or None
        The feed URL, or None if reading a local file.
    file_path : str or None
        The local file path, or None if downloading a URL.
    timeout : int
        How many seconds to wait for the download before giving up.

    RETURNS
    -------
    str
        The full raw text of the feed.

    RAISES
    ------
    SystemExit
        If the download or file read fails, the script stops with a clear
        message and a non-zero exit code so automation can detect the failure.
    """
    if url:
        try:
            # Build a request with a clear User-Agent so the SOC can identify us.
            request = urllib.request.Request(
                url,
                headers={"User-Agent": f"CCD-SOC-EDL/{__version__}"},
            )
            # create_default_context() turns ON proper certificate verification.
            context = ssl.create_default_context()
            with urllib.request.urlopen(request, timeout=timeout, context=context) as response:
                return response.read().decode("utf-8", errors="replace")
        except Exception as problem:
            sys.exit(f"ERROR: could not download the feed from {url}\n       reason: {problem}")
    else:
        try:
            with open(file_path, "r", encoding="utf-8", errors="replace") as handle:
                return handle.read()
        except Exception as problem:
            sys.exit(f"ERROR: could not read the local file {file_path}\n       reason: {problem}")


# =============================================================================
#  SECTION 3 -- THE STATE FILE (remembering first_seen / last_seen dates)
# =============================================================================
#  The firewall only ever sees the plain .txt EDL. But WE need to remember when
#  we first/last saw each entry so we can support "aging". We keep that memory
#  in a small JSON file next to the EDL. This function loads it; if it's the
#  first run ever, we start with an empty memory.
# -----------------------------------------------------------------------------

def load_state(state_path: str) -> dict:
    """
    Load the date-tracking memory from disk, or start fresh if none exists.

    WHAT IT DOES
    ------------
    Reads the JSON state file that maps each entry to its first_seen/last_seen
    dates and whether it is a domain or an ip. If the file is missing (first run)
    or unreadable, returns an empty structure so the script can still proceed.

    PARAMETERS
    ----------
    state_path : str
        Path to the <name>_state.json file.

    RETURNS
    -------
    dict
        { "entries": { "<value>": {"kind","first_seen","last_seen"} , ... } }
    """
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
                # Make sure the expected key exists even if the file was odd.
                if "entries" not in data:
                    data["entries"] = {}
                return data
        except Exception:
            # A corrupt state file should not stop us; warn and start clean.
            print(f"WARNING: state file {state_path} was unreadable; starting fresh.")
            return {"entries": {}}
    return {"entries": {}}


def save_state(state_path: str, state: dict) -> None:
    """
    Write the date-tracking memory back to disk.

    WHAT IT DOES
    ------------
    Saves the updated entries-with-dates structure as pretty-printed JSON so a
    human can read it if needed. This file is the script's memory between runs;
    deleting it resets all first_seen/last_seen dates.

    PARAMETERS
    ----------
    state_path : str
        Path to the <name>_state.json file.
    state : dict
        The structure to save.
    """
    with open(state_path, "w", encoding="utf-8") as handle:
        json.dump(state, handle, indent=2, sort_keys=True)


# =============================================================================
#  SECTION 4 -- THE MERGE (combine yesterday's EDL with today's feed)
# =============================================================================

def merge_feed_into_state(today_entries: dict, state: dict, today: str) -> dict:
    """
    Combine today's freshly-validated entries with everything we knew before.

    WHAT IT DOES
    ------------
    Implements the "accretive + aging" model:
      * If an entry is BRAND NEW, add it with first_seen = last_seen = today.
      * If an entry was already known AND is in today's feed, advance its
        last_seen to today (it's still active).
      * If an entry was known but is NOT in today's feed, keep it but DO NOT
        advance last_seen (it ages).

    Because the caller has already re-validated every previously-known entry,
    anything that became invalid was dropped before reaching here -- so the
    merged result can never reintroduce malformed data.

    PARAMETERS
    ----------
    today_entries : dict
        Valid entries found in today's feed: { "<value>": "domain"|"ip" }.
    state : dict
        The loaded memory of previously published entries (already re-validated
        and pruned of anything now-invalid by the caller).
    today : str
        Today's date as "YYYY-MM-DD".

    RETURNS
    -------
    dict
        The updated state with first_seen/last_seen correct for every entry.
    """
    entries = state["entries"]

    # Walk through everything valid in today's feed.
    for value, kind in today_entries.items():
        if value in entries:
            # Known entry, seen again today -> refresh last_seen.
            entries[value]["last_seen"] = today
            entries[value]["kind"] = kind          # keep kind current
        else:
            # Never seen before -> record it with both dates set to today.
            entries[value] = {"kind": kind, "first_seen": today, "last_seen": today}

    # Entries already in 'state' but absent from today's feed are simply left
    # untouched -- they stay published, but their last_seen does not advance.
    return state


# =============================================================================
#  SECTION 5 -- WRITING THE OUTPUT (EDL files + report)
# =============================================================================

def write_edls(out_dir: str, name: str, state: dict):
    """
    Write the two clean EDL text files the firewall will download.

    WHAT IT DOES
    ------------
    Splits the merged, validated entries into domains and IPs, sorts them for a
    stable diff-friendly order, de-duplicates one final time as a belt-and-
    suspenders check, and writes <name>_domains.txt and <name>_ips.txt.

    The EDL files contain ONLY the entries themselves plus a single leading
    comment line (PAN-OS ignores lines starting with '#'). No dates go in the
    EDL -- the firewall doesn't need them; they live in the state file.

    PARAMETERS
    ----------
    out_dir : str
        Directory to write into.
    name : str
        Base name for the files (e.g. "SOC-CTI").
    state : dict
        The merged memory containing every entry and its kind.

    RETURNS
    -------
    tuple(int, int)
        (number_of_domains_written, number_of_ips_written)
    """
    # Pull values out by kind, using a set to guarantee no duplicates.
    domains = sorted({v for v, meta in state["entries"].items() if meta["kind"] == "domain"})
    ips = sorted({v for v, meta in state["entries"].items() if meta["kind"] == "ip"})

    stamp = datetime.date.today().isoformat()

    domain_path = os.path.join(out_dir, f"{name}_domains.txt")
    with open(domain_path, "w", encoding="utf-8") as handle:
        handle.write(f"# {name} domain EDL  |  {len(domains)} entries  |  built {stamp}  |  builder v{__version__}\n")
        handle.write("\n".join(domains))
        if domains:
            handle.write("\n")

    ip_path = os.path.join(out_dir, f"{name}_ips.txt")
    with open(ip_path, "w", encoding="utf-8") as handle:
        handle.write(f"# {name} ip EDL  |  {len(ips)} entries  |  built {stamp}  |  builder v{__version__}\n")
        handle.write("\n".join(ips))
        if ips:
            handle.write("\n")

    return len(domains), len(ips)


def write_report(out_dir, name, source, lines_in, counters, advisories,
                 added, refreshed, aged, total_domains, total_ips, stale):
    """
    Write the human-readable "what happened this run" report.

    WHAT IT DOES
    ------------
    Produces a plain-text report that tells the operator, in order: how many
    lines came in, what was auto-fixed, what was rejected (and the actual
    values, so they can be eyeballed), how the merge changed the published list,
    and which entries are now stale. This is the file a human reads to manage
    data quality.

    PARAMETERS
    ----------
    out_dir, name, source : str
        Where to write, the EDL base name, and where the feed came from.
    lines_in : int
        Total lines read from today's feed.
    counters : dict
        Tally of every auto-fix and rejection category.
    advisories : dict
        The actual rejected values, grouped by reason.
    added, refreshed, aged : int
        Merge outcome: brand-new, seen-again, and not-seen-today counts.
    total_domains, total_ips : int
        Final published counts.
    stale : list
        Entries not seen in the configured staleness window.

    RETURNS
    -------
    str
        The path of the report file written.
    """
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(out_dir, f"{name}_report_{stamp}.txt")

    rejected_total = (counters["blank"] + counters["comment_or_metadata"]
                      + counters["sha_hash"] + counters["partial_ip"]
                      + counters["question_prefixed"] + counters["email_rejected"]
                      + counters["unfixable_whitespace"] + counters["bare_tld"]
                      + counters["no_tld_or_invalid"])

    lines = []
    lines.append(f"SOC EDL Build Report  --  {name}")
    lines.append("=" * 60)
    lines.append(f"Builder version : {__version__}")
    lines.append(f"Source          : {source}")
    lines.append(f"Run time        : {datetime.datetime.now().isoformat(timespec='seconds')}")
    lines.append(f"Lines read in   : {lines_in}")
    lines.append("")
    lines.append("-- AUTO-FIXED (safe corrections applied automatically) --")
    lines.append(f"  Defanged re-fanged (evil[.]com -> evil.com) : {counters['defang_fixed']}")
    lines.append(f"  Lower-cased                                  : {counters['lowercased']}")
    lines.append(f"  Trailing dot stripped                        : {counters['trailing_dot_fixed']}")
    lines.append(f"  Spaces around dot collapsed                  : {counters['space_collapsed']}")
    lines.append("")
    lines.append("-- REJECTED (bypassed, never written to the EDL) --")
    lines.append(f"  Blank lines                : {counters['blank']}")
    lines.append(f"  Comment / metadata lines   : {counters['comment_or_metadata']}")
    lines.append(f"  SHA file hashes            : {counters['sha_hash']}")
    lines.append(f"  Partial IPs                : {counters['partial_ip']}")
    lines.append(f"  '?'-prefixed artifacts     : {counters['question_prefixed']}")
    lines.append(f"  Email addresses            : {counters['email_rejected']}")
    lines.append(f"  Unfixable whitespace/phrase: {counters['unfixable_whitespace']}")
    lines.append(f"  Bare TLD (e.g. .ru)        : {counters['bare_tld']}")
    lines.append(f"  No valid TLD / invalid     : {counters['no_tld_or_invalid']}")
    lines.append(f"  REJECTED TOTAL             : {rejected_total}")
    lines.append("")
    lines.append("-- MERGE RESULT (accretive + aging) --")
    lines.append(f"  Brand-new entries added    : {added}")
    lines.append(f"  Existing entries refreshed : {refreshed}")
    lines.append(f"  Entries not in today's feed: {aged}  (kept, last_seen unchanged)")
    lines.append("")
    lines.append("-- PUBLISHED EDL TOTALS --")
    lines.append(f"  Domains : {total_domains}  -> {name}_domains.txt")
    lines.append(f"  IPs     : {total_ips}  -> {name}_ips.txt")
    lines.append(f"  Stale (not seen recently)  : {len(stale)}")
    lines.append("")

    # Print the actual rejected values so a human can review them. We cap each
    # list so the report stays readable even on a huge, messy feed.
    def dump(title, items, cap=50):
        if not items:
            return
        lines.append(f"-- ADVISORY: {title} ({len(items)} total, showing up to {cap}) --")
        for item in items[:cap]:
            lines.append(f"    {item}")
        lines.append("")

    dump("Email addresses rejected", advisories["email_rejected"])
    dump("'?'-prefixed artifacts", advisories["question_prefixed"])
    dump("Bare TLD entries (use a URL category rule instead)", advisories["bare_tld"])
    dump("Partial IPs", advisories["partial_ip"])
    dump("Unfixable whitespace/phrases", advisories["unfixable_whitespace"])
    dump("No valid TLD / invalid domains", advisories["no_tld_or_invalid"])
    if stale:
        dump("Stale entries (candidates for pruning)", stale)

    with open(path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return path


# =============================================================================
#  SECTION 6 -- MAIN (ties everything together in order)
# =============================================================================

def main():
    """
    Run the whole build: read flags, load feed + memory, validate, merge, write.

    WHAT IT DOES (step by step)
    ---------------------------
    1. Read the command-line options.
    2. Load today's feed (URL or file).
    3. Load the date-tracking memory from the previous run.
    4. RE-VALIDATE every previously-known entry (safest option): anything that
       is no longer valid is dropped from memory before the merge.
    5. Validate every line of today's feed, auto-fixing and rejecting as needed.
    6. Merge today's valid entries into memory (accretive + aging).
    7. Compute which entries are now "stale".
    8. Unless --dry-run, write the two EDL files, the state file, and a report.
    """
    # ---- 1. command-line options ----
    parser = argparse.ArgumentParser(
        description="Build/refresh a Palo Alto domain+IP EDL from a SOC feed "
                    "(accretive + aging merge, full validation)."
    )
    source_group = parser.add_mutually_exclusive_group(required=False)
    source_group.add_argument("--url", help="URL of the SOC feed to download")
    source_group.add_argument("--file", help="local feed file to read instead of a URL")
    parser.add_argument("--name", default="SOC-CTI",
                        help="base name for the output files (default: SOC-CTI)")
    parser.add_argument("--out", default="./edl_out",
                        help="output directory (default: ./edl_out)")
    parser.add_argument("--stale-days", type=int, default=90,
                        help="entries not seen in this many days are flagged stale (default: 90)")
    parser.add_argument("--timeout", type=int, default=30,
                        help="download timeout in seconds (default: 30)")
    parser.add_argument("--dry-run", action="store_true",
                        help="show what would happen but write nothing")
    parser.add_argument("--version", action="store_true",
                        help="print the script version and exit")
    args = parser.parse_args()

    # ---- --version short-circuit (CCD convention: exits immediately) ----
    if args.version:
        print(f"soc_edl_builder.py v{__version__}")
        return

    # A source is required unless we were only asked for --version.
    if not args.url and not args.file:
        sys.exit("ERROR: provide a feed with --url or --file (or use --version).")

    today = datetime.date.today().isoformat()
    source = args.url or args.file

    # ---- 2. load today's feed ----
    raw_text = load_feed(args.url, args.file, args.timeout)
    feed_lines = raw_text.splitlines()

    # ---- prepare the tally counters and advisory lists ----
    counters = {key: 0 for key in [
        "blank", "comment_or_metadata", "ip_accepted", "sha_hash", "partial_ip",
        "question_prefixed", "defang_fixed", "email_rejected", "space_collapsed",
        "unfixable_whitespace", "trailing_dot_fixed", "bare_tld", "lowercased",
        "domain_accepted", "no_tld_or_invalid",
    ]}
    advisories = {key: [] for key in [
        "partial_ip", "question_prefixed", "email_rejected",
        "unfixable_whitespace", "bare_tld", "no_tld_or_invalid",
    ]}

    # ---- 5a. validate today's feed line by line ----
    # (numbered out of order vs the docstring on purpose: we build today's set
    #  first, then re-validate memory, because both feed into the same merge.)
    today_entries = {}     # value -> "domain" | "ip"
    for line in feed_lines:
        kind, value = classify_and_clean(line, counters, advisories)
        if kind is not None:
            today_entries[value] = kind

    # ---- 3. load memory from last run ----
    os.makedirs(args.out, exist_ok=True) if not args.dry_run else None
    state_path = os.path.join(args.out, f"{args.name}_state.json")
    state = load_state(state_path)

    # ---- 4. RE-VALIDATE every previously-known entry ----
    # We re-run each stored entry through the SAME validator. If it no longer
    # passes (rules tightened, or the entry was somehow corrupted), we drop it.
    # This is why "malformed data can never be reintroduced".
    dropped_on_revalidation = []
    revalidated = {}
    throwaway_counters = {k: 0 for k in counters}      # we don't tally re-checks
    throwaway_advisories = {k: [] for k in advisories}
    for value, meta in state["entries"].items():
        kind, clean_value = classify_and_clean(value, throwaway_counters, throwaway_advisories)
        if kind is not None and clean_value == value:
            revalidated[value] = meta            # still valid -> keep with its dates
        else:
            dropped_on_revalidation.append(value)  # no longer valid -> drop it
    state["entries"] = revalidated

    # ---- 6. merge today's valid entries into memory ----
    # Count outcomes for the report BEFORE mutating, so the numbers are honest.
    known_before = set(state["entries"].keys())
    added = sum(1 for v in today_entries if v not in known_before)
    refreshed = sum(1 for v in today_entries if v in known_before)
    aged = sum(1 for v in known_before if v not in today_entries)
    state = merge_feed_into_state(today_entries, state, today)

    # ---- 7. compute stale entries (not seen within --stale-days) ----
    cutoff = datetime.date.today() - datetime.timedelta(days=args.stale_days)
    stale = []
    for value, meta in state["entries"].items():
        try:
            last = datetime.date.fromisoformat(meta["last_seen"])
            if last < cutoff:
                stale.append(value)
        except Exception:
            pass  # if a date is somehow unparseable, just don't flag it stale

    # ---- count final totals for the report ----
    total_domains = sum(1 for m in state["entries"].values() if m["kind"] == "domain")
    total_ips = sum(1 for m in state["entries"].values() if m["kind"] == "ip")

    # ---- 8. write everything (unless this is a dry run) ----
    if args.dry_run:
        print("[DRY RUN] nothing written. Summary of what WOULD happen:")
        print(f"  feed lines read     : {len(feed_lines)}")
        print(f"  valid in feed today : {len(today_entries)}")
        print(f"  re-validation drops : {len(dropped_on_revalidation)}")
        print(f"  new / refreshed     : {added} / {refreshed}")
        print(f"  aged (kept)         : {aged}")
        print(f"  published domains   : {total_domains}")
        print(f"  published ips       : {total_ips}")
        print(f"  stale (> {args.stale_days}d)      : {len(stale)}")
        return

    n_dom, n_ip = write_edls(args.out, args.name, state)
    save_state(state_path, state)
    report_path = write_report(args.out, args.name, source, len(feed_lines),
                               counters, advisories, added, refreshed, aged,
                               n_dom, n_ip, stale)

    # ---- final one-line summary to the screen ----
    print(json.dumps({
        "version": __version__,
        "source": source,
        "feed_lines": len(feed_lines),
        "valid_today": len(today_entries),
        "revalidation_drops": len(dropped_on_revalidation),
        "added": added, "refreshed": refreshed, "aged": aged,
        "published_domains": n_dom, "published_ips": n_ip,
        "stale": len(stale),
        "report": report_path,
    }, indent=2))


# This standard Python idiom means "only run main() if this file was executed
# directly, not if it was imported by another script."
if __name__ == "__main__":
    main()
