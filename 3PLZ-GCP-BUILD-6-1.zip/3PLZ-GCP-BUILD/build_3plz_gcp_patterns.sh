#!/usr/bin/env bash
set -euo pipefail

# 3PLZ POC physical-infrastructure emulation builder.
#
# Creates one GCP project environment containing:
#   - Two Pattern 1 remote partner emulation VPCs: p1a and p1b
#   - Two Pattern 2 VXLAN/IPVLAN cluster VPCs: p2a and p2b
#
# Run from Google Cloud Shell or a workstation with gcloud authenticated.
#
# Required:
#   export PROJECT_ID="your-project-id"
#
# Strongly recommended:
#   export REGION="us-east1"
#   export ZONE="us-east1-b"
#   export HUB_PUBLIC_CIDR="x.x.x.x/32"
#
# Optional project creation:
#   export CREATE_PROJECT="true"
#   export BILLING_ACCOUNT="000000-000000-000000"
#   export FOLDER_ID="1234567890"
#   # or export ORG_ID="1234567890"
#
# Appliance image selection:
#
#   ./build_3plz_gcp_patterns.sh -palo_alto
#   ./build_3plz_gcp_patterns.sh -Rocky_Linux-StrongSwan
#   ./build_3plz_gcp_patterns.sh -Cisco_C800V
#   ./build_3plz_gcp_patterns.sh -Cisco_1000V
#
# The script maps these flags to APPLIANCE_IMAGE_PROJECT and
# APPLIANCE_IMAGE_FAMILY. Marketplace image naming can vary by license, SKU,
# and organization entitlement, so each mapping can be overridden with vendor-
# specific environment variables before execution.
#
# Examples:
#   export PALO_ALTO_IMAGE_PROJECT="your-pa-marketplace-image-project"
#   export PALO_ALTO_IMAGE_FAMILY="your-pa-image-family"
#   ./build_3plz_gcp_patterns.sh -palo_alto
#
#   export CISCO_C800V_IMAGE_PROJECT="your-cisco-image-project"
#   export CISCO_C800V_IMAGE_FAMILY="your-cisco-c800v-family"
#   ./build_3plz_gcp_patterns.sh -Cisco_C800V

usage() {
  cat <<'EOF'
Usage:
  build_3plz_gcp_patterns.sh [appliance flag]

Appliance flags:
  -palo_alto                  Use Palo Alto VM-Series image variables.
  -Rocky_Linux-StrongSwan     Use Rocky Linux and bootstrap strongSwan.
  -Cisco_C800V                Use Cisco Catalyst 8000V image variables.
  -Cisco_1000V                Use Cisco CSR 1000V image variables.
  -debian_placeholder         Use Debian placeholder appliance image.

Required environment:
  PROJECT_ID                  Existing GCP project ID, unless CREATE_PROJECT=true.

Common optional environment:
  REGION                      Default: us-east1
  ZONE                        Default: us-east1-b
  HUB_PUBLIC_CIDR             Default: 0.0.0.0/0; should be hub-public-ip/32.
  CREATE_PROJECT              true/false. Default: false.
  BILLING_ACCOUNT             Required when CREATE_PROJECT=true and billing must be linked.
  FOLDER_ID or ORG_ID         Optional parent when CREATE_PROJECT=true.

Vendor image override variables:
  PALO_ALTO_IMAGE_PROJECT
  PALO_ALTO_IMAGE_FAMILY
  ROCKY_STRONGSWAN_IMAGE_PROJECT
  ROCKY_STRONGSWAN_IMAGE_FAMILY
  CISCO_C800V_IMAGE_PROJECT
  CISCO_C800V_IMAGE_FAMILY
  CISCO_1000V_IMAGE_PROJECT
  CISCO_1000V_IMAGE_FAMILY

Notes:
  Marketplace image names and entitlements vary. If a vendor default image
  mapping does not match your GCP Marketplace entitlement, set the matching
  override variables before running.
EOF
}

APPLIANCE_PROFILE="${APPLIANCE_PROFILE:-debian_placeholder}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    -palo_alto|--palo_alto|--palo-alto)
      APPLIANCE_PROFILE="palo_alto"
      shift
      ;;
    -Rocky_Linux-StrongSwan|--Rocky_Linux-StrongSwan|--rocky-linux-strongswan|--rocky_strongswan)
      APPLIANCE_PROFILE="rocky_linux_strongswan"
      shift
      ;;
    -Cisco_C800V|--Cisco_C800V|--cisco-c800v|--c800v)
      APPLIANCE_PROFILE="cisco_c800v"
      shift
      ;;
    -Cisco_1000V|--Cisco_1000V|--cisco-1000v|--csr1000v)
      APPLIANCE_PROFILE="cisco_1000v"
      shift
      ;;
    -debian_placeholder|--debian-placeholder|--debian)
      APPLIANCE_PROFILE="debian_placeholder"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "ERROR: Unknown argument: $1"
      usage
      exit 1
      ;;
  esac
done

PROJECT_ID="${PROJECT_ID:-}"
REGION="${REGION:-us-east1}"
ZONE="${ZONE:-us-east1-b}"
CREATE_PROJECT="${CREATE_PROJECT:-false}"
BILLING_ACCOUNT="${BILLING_ACCOUNT:-}"
FOLDER_ID="${FOLDER_ID:-}"
ORG_ID="${ORG_ID:-}"
HUB_PUBLIC_CIDR="${HUB_PUBLIC_CIDR:-0.0.0.0/0}"

MGMT_IMAGE_PROJECT="${MGMT_IMAGE_PROJECT:-debian-cloud}"
MGMT_IMAGE_FAMILY="${MGMT_IMAGE_FAMILY:-debian-12}"
HOST_IMAGE_PROJECT="${HOST_IMAGE_PROJECT:-debian-cloud}"
HOST_IMAGE_FAMILY="${HOST_IMAGE_FAMILY:-debian-12}"

APPLIANCE_STARTUP_SCRIPT_FILE=""

case "${APPLIANCE_PROFILE}" in
  debian_placeholder)
    APPLIANCE_VENDOR_LABEL="debian-placeholder"
    APPLIANCE_IMAGE_PROJECT="${APPLIANCE_IMAGE_PROJECT:-debian-cloud}"
    APPLIANCE_IMAGE_FAMILY="${APPLIANCE_IMAGE_FAMILY:-debian-12}"
    ;;
  palo_alto)
    APPLIANCE_VENDOR_LABEL="palo-alto-vm-series"
    APPLIANCE_IMAGE_PROJECT="${APPLIANCE_IMAGE_PROJECT:-${PALO_ALTO_IMAGE_PROJECT:-paloaltonetworksgcp-public}}"
    APPLIANCE_IMAGE_FAMILY="${APPLIANCE_IMAGE_FAMILY:-${PALO_ALTO_IMAGE_FAMILY:-vmseries-flex-byol}}"
    ;;
  rocky_linux_strongswan)
    APPLIANCE_VENDOR_LABEL="rocky-linux-strongswan"
    APPLIANCE_IMAGE_PROJECT="${APPLIANCE_IMAGE_PROJECT:-${ROCKY_STRONGSWAN_IMAGE_PROJECT:-rocky-linux-cloud}}"
    APPLIANCE_IMAGE_FAMILY="${APPLIANCE_IMAGE_FAMILY:-${ROCKY_STRONGSWAN_IMAGE_FAMILY:-rocky-linux-9}}"
    APPLIANCE_STARTUP_SCRIPT_FILE="/tmp/3plz-rocky-strongswan-startup.sh"
    cat > "${APPLIANCE_STARTUP_SCRIPT_FILE}" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
dnf -y install strongswan tcpdump bind-utils traceroute policycoreutils-python-utils || true
systemctl enable strongswan || true
sysctl -w net.ipv4.ip_forward=1
cat >/etc/sysctl.d/99-3plz-ip-forward.conf <<SYSCTL
net.ipv4.ip_forward=1
SYSCTL
EOF
    ;;
  cisco_c800v)
    APPLIANCE_VENDOR_LABEL="cisco-c800v"
    APPLIANCE_IMAGE_PROJECT="${APPLIANCE_IMAGE_PROJECT:-${CISCO_C800V_IMAGE_PROJECT:-cisco-public}}"
    APPLIANCE_IMAGE_FAMILY="${APPLIANCE_IMAGE_FAMILY:-${CISCO_C800V_IMAGE_FAMILY:-cisco-c8000v-byol}}"
    ;;
  cisco_1000v)
    APPLIANCE_VENDOR_LABEL="cisco-1000v"
    APPLIANCE_IMAGE_PROJECT="${APPLIANCE_IMAGE_PROJECT:-${CISCO_1000V_IMAGE_PROJECT:-cisco-public}}"
    APPLIANCE_IMAGE_FAMILY="${APPLIANCE_IMAGE_FAMILY:-${CISCO_1000V_IMAGE_FAMILY:-cisco-csr-1000v-byol}}"
    ;;
  *)
    echo "ERROR: Unsupported APPLIANCE_PROFILE=${APPLIANCE_PROFILE}"
    exit 1
    ;;
esac

MGMT_MACHINE_TYPE="${MGMT_MACHINE_TYPE:-e2-standard-2}"
APPLIANCE_MACHINE_TYPE="${APPLIANCE_MACHINE_TYPE:-e2-standard-4}"
WORKLOAD_MACHINE_TYPE="${WORKLOAD_MACHINE_TYPE:-e2-standard-8}"

MGMT_DISK_SIZE="${MGMT_DISK_SIZE:-100GB}"
APPLIANCE_DISK_SIZE="${APPLIANCE_DISK_SIZE:-256GB}"
PATTERN1_HOST_DISK_SIZE="${PATTERN1_HOST_DISK_SIZE:-512GB}"
PATTERN2_NODE_DISK_SIZE="${PATTERN2_NODE_DISK_SIZE:-1TB}"

if [[ -z "${PROJECT_ID}" ]]; then
  echo "ERROR: PROJECT_ID is required."
  echo "Example: export PROJECT_ID='my-3plz-poc-lab'"
  exit 1
fi

echo "Using project: ${PROJECT_ID}"
echo "Using region:  ${REGION}"
echo "Using zone:    ${ZONE}"
echo "Hub CIDR:      ${HUB_PUBLIC_CIDR}"
echo "Appliance:     ${APPLIANCE_VENDOR_LABEL}"
echo "Image project: ${APPLIANCE_IMAGE_PROJECT}"
echo "Image family:  ${APPLIANCE_IMAGE_FAMILY}"

if [[ "${HUB_PUBLIC_CIDR}" == "0.0.0.0/0" ]]; then
  echo "WARNING: HUB_PUBLIC_CIDR is 0.0.0.0/0. Replace this with the external hub public IP/CIDR before using outside a closed lab."
fi

run() {
  echo
  echo "+ $*"
  "$@"
}

ensure_project() {
  if gcloud projects describe "${PROJECT_ID}" >/dev/null 2>&1; then
    echo "Project ${PROJECT_ID} already exists."
  else
    if [[ "${CREATE_PROJECT}" != "true" ]]; then
      echo "ERROR: Project ${PROJECT_ID} does not exist. Set CREATE_PROJECT=true with billing/folder/org values, or create it first."
      exit 1
    fi

    local parent_args=()
    if [[ -n "${FOLDER_ID}" ]]; then
      parent_args=(--folder="${FOLDER_ID}")
    elif [[ -n "${ORG_ID}" ]]; then
      parent_args=(--organization="${ORG_ID}")
    fi

    run gcloud projects create "${PROJECT_ID}" "${parent_args[@]}"

    if [[ -n "${BILLING_ACCOUNT}" ]]; then
      run gcloud billing projects link "${PROJECT_ID}" --billing-account="${BILLING_ACCOUNT}"
    else
      echo "WARNING: BILLING_ACCOUNT not set. You must link billing before Compute Engine resources can be created."
    fi
  fi

  run gcloud config set project "${PROJECT_ID}"
  run gcloud services enable compute.googleapis.com cloudresourcemanager.googleapis.com
}

ensure_network() {
  local network="$1"
  if gcloud compute networks describe "${network}" >/dev/null 2>&1; then
    echo "Network ${network} already exists."
  else
    run gcloud compute networks create "${network}" --subnet-mode=custom
  fi
}

ensure_subnet() {
  local subnet="$1"
  local network="$2"
  local cidr="$3"
  if gcloud compute networks subnets describe "${subnet}" --region="${REGION}" >/dev/null 2>&1; then
    echo "Subnet ${subnet} already exists."
  else
    run gcloud compute networks subnets create "${subnet}" \
      --network="${network}" \
      --region="${REGION}" \
      --range="${cidr}"
  fi
}

ensure_address() {
  local name="$1"
  if gcloud compute addresses describe "${name}" --region="${REGION}" >/dev/null 2>&1; then
    echo "Address ${name} already exists."
  else
    run gcloud compute addresses create "${name}" --region="${REGION}"
  fi
}

ensure_firewall() {
  local name="$1"
  shift
  if gcloud compute firewall-rules describe "${name}" >/dev/null 2>&1; then
    echo "Firewall rule ${name} already exists."
  else
    run gcloud compute firewall-rules create "${name}" "$@"
  fi
}

ensure_instance_absent_or_skip() {
  local name="$1"
  if gcloud compute instances describe "${name}" --zone="${ZONE}" >/dev/null 2>&1; then
    echo "Instance ${name} already exists; skipping."
    return 0
  fi
  return 1
}

create_management_vm() {
  local env="$1"
  local network="$2"
  local subnet="$3"
  local name="${env}-mgmt"

  if ensure_instance_absent_or_skip "${name}"; then
    return
  fi

  run gcloud compute instances create "${name}" \
    --zone="${ZONE}" \
    --machine-type="${MGMT_MACHINE_TYPE}" \
    --image-family="${MGMT_IMAGE_FAMILY}" \
    --image-project="${MGMT_IMAGE_PROJECT}" \
    --boot-disk-size="${MGMT_DISK_SIZE}" \
    --boot-disk-type=pd-balanced \
    --tags="${env}-mgmt" \
    --network-interface="network=${network},subnet=${subnet},no-address" \
    --metadata="enable-oslogin=TRUE,block-project-ssh-keys=FALSE"
}

create_appliance_two_nic() {
  local env="$1"
  local network="$2"
  local public_subnet="$3"
  local private_subnet="$4"
  local address_name="$5"
  local private_ip="$6"
  local name="${env}-vpn-gw"
  local public_ip
  public_ip="$(gcloud compute addresses describe "${address_name}" --region="${REGION}" --format='value(address)')"

  if ensure_instance_absent_or_skip "${name}"; then
    return
  fi

  local startup_args=()
  if [[ -n "${APPLIANCE_STARTUP_SCRIPT_FILE}" ]]; then
    startup_args=(--metadata-from-file="startup-script=${APPLIANCE_STARTUP_SCRIPT_FILE}")
  fi

  run gcloud compute instances create "${name}" \
    --zone="${ZONE}" \
    --machine-type="${APPLIANCE_MACHINE_TYPE}" \
    --can-ip-forward \
    --no-service-account \
    --image-family="${APPLIANCE_IMAGE_FAMILY}" \
    --image-project="${APPLIANCE_IMAGE_PROJECT}" \
    --boot-disk-size="${APPLIANCE_DISK_SIZE}" \
    --boot-disk-type=pd-balanced \
    --tags="${env}-appliance" \
    --network-interface="network=${network},subnet=${public_subnet},address=${public_ip}" \
    --network-interface="network=${network},subnet=${private_subnet},private-network-ip=${private_ip},no-address" \
    --metadata="enable-oslogin=FALSE,block-project-ssh-keys=TRUE,appliance-profile=${APPLIANCE_PROFILE}" \
    "${startup_args[@]}"
}

create_appliance_one_nic() {
  local env="$1"
  local network="$2"
  local subnet="$3"
  local address_name="$4"
  local name="${env}-vpn-gw"
  local public_ip
  public_ip="$(gcloud compute addresses describe "${address_name}" --region="${REGION}" --format='value(address)')"

  if ensure_instance_absent_or_skip "${name}"; then
    return
  fi

  local startup_args=()
  if [[ -n "${APPLIANCE_STARTUP_SCRIPT_FILE}" ]]; then
    startup_args=(--metadata-from-file="startup-script=${APPLIANCE_STARTUP_SCRIPT_FILE}")
  fi

  run gcloud compute instances create "${name}" \
    --zone="${ZONE}" \
    --machine-type="${APPLIANCE_MACHINE_TYPE}" \
    --can-ip-forward \
    --no-service-account \
    --image-family="${APPLIANCE_IMAGE_FAMILY}" \
    --image-project="${APPLIANCE_IMAGE_PROJECT}" \
    --boot-disk-size="${APPLIANCE_DISK_SIZE}" \
    --boot-disk-type=pd-balanced \
    --tags="${env}-appliance" \
    --network-interface="network=${network},subnet=${subnet},address=${public_ip}" \
    --metadata="enable-oslogin=FALSE,block-project-ssh-keys=TRUE,appliance-profile=${APPLIANCE_PROFILE}" \
    "${startup_args[@]}"
}

create_pattern1_host() {
  local env="$1"
  local network="$2"
  local subnet="$3"
  local index="$4"
  local name="${env}-partner-host-${index}"

  if ensure_instance_absent_or_skip "${name}"; then
    return
  fi

  run gcloud compute instances create "${name}" \
    --zone="${ZONE}" \
    --machine-type="${WORKLOAD_MACHINE_TYPE}" \
    --no-service-account \
    --image-family="${HOST_IMAGE_FAMILY}" \
    --image-project="${HOST_IMAGE_PROJECT}" \
    --boot-disk-size="${PATTERN1_HOST_DISK_SIZE}" \
    --boot-disk-type=pd-balanced \
    --tags="${env}-host" \
    --network-interface="network=${network},subnet=${subnet},no-address" \
    --metadata="enable-oslogin=FALSE,block-project-ssh-keys=TRUE"
}

create_pattern2_node() {
  local env="$1"
  local network="$2"
  local subnet_a="$3"
  local subnet_b="$4"
  local index="$5"
  local name="${env}-cluster-node-${index}"

  if ensure_instance_absent_or_skip "${name}"; then
    return
  fi

  run gcloud compute instances create "${name}" \
    --zone="${ZONE}" \
    --machine-type="${WORKLOAD_MACHINE_TYPE}" \
    --can-ip-forward \
    --no-service-account \
    --image-family="${HOST_IMAGE_FAMILY}" \
    --image-project="${HOST_IMAGE_PROJECT}" \
    --boot-disk-size="${PATTERN2_NODE_DISK_SIZE}" \
    --boot-disk-type=pd-balanced \
    --tags="${env}-node" \
    --network-interface="network=${network},subnet=${subnet_a},no-address" \
    --network-interface="network=${network},subnet=${subnet_b},no-address" \
    --metadata="enable-oslogin=FALSE,block-project-ssh-keys=TRUE"
}

create_common_firewall() {
  local env="$1"
  local network="$2"
  local mgmt_cidr="$3"
  local workload_cidrs="$4"

  ensure_firewall "${env}-allow-iap-ssh-to-mgmt" \
    --network="${network}" \
    --allow=tcp:22 \
    --source-ranges=35.235.240.0/20 \
    --target-tags="${env}-mgmt"

  ensure_firewall "${env}-allow-mgmt-to-appliance-and-hosts" \
    --network="${network}" \
    --allow=tcp:22,tcp:443,tcp:8443,icmp \
    --source-ranges="${mgmt_cidr}" \
    --target-tags="${env}-appliance,${env}-host,${env}-node"

  ensure_firewall "${env}-allow-ipsec-from-hub" \
    --network="${network}" \
    --allow=udp:500,udp:4500,esp \
    --source-ranges="${HUB_PUBLIC_CIDR}" \
    --target-tags="${env}-appliance"

  ensure_firewall "${env}-allow-workloads-to-appliance" \
    --network="${network}" \
    --allow=tcp,udp,icmp \
    --source-ranges="${workload_cidrs}" \
    --target-tags="${env}-appliance"
}

create_pattern1() {
  local env="$1"
  local octet="$2"
  local network="${env}-vpc"

  local public_subnet="${env}-public-subnet"
  local gw_private_subnet="${env}-gw-private-subnet"
  local mgmt_subnet="${env}-mgmt-subnet"
  local address_name="${env}-vpn-gw-public-ip"
  local gw_private_ip="10.${octet}.10.10"

  echo
  echo "=== Creating Pattern 1 environment: ${env} ==="

  ensure_network "${network}"
  ensure_subnet "${public_subnet}" "${network}" "10.${octet}.0.0/24"
  ensure_subnet "${gw_private_subnet}" "${network}" "10.${octet}.10.0/24"
  ensure_subnet "${mgmt_subnet}" "${network}" "10.${octet}.15.0/24"

  for i in 1 2 3 4 5; do
    ensure_subnet "${env}-partner-segment-${i}" "${network}" "10.${octet}.$((20 + i)).0/24"
  done

  ensure_address "${address_name}"

  create_common_firewall "${env}" "${network}" "10.${octet}.15.0/24" "10.${octet}.21.0/24,10.${octet}.22.0/24,10.${octet}.23.0/24,10.${octet}.24.0/24,10.${octet}.25.0/24"

  ensure_firewall "${env}-allow-appliance-to-partner-hosts" \
    --network="${network}" \
    --allow=tcp,udp,icmp \
    --source-ranges="${gw_private_ip}/32" \
    --target-tags="${env}-host"

  create_management_vm "${env}" "${network}" "${mgmt_subnet}"
  create_appliance_two_nic "${env}" "${network}" "${public_subnet}" "${gw_private_subnet}" "${address_name}" "${gw_private_ip}"

  for i in 1 2 3 4 5; do
    create_pattern1_host "${env}" "${network}" "${env}-partner-segment-${i}" "${i}"
  done
}

create_pattern2() {
  local env="$1"
  local octet="$2"
  local network="${env}-vpc"

  local gateway_subnet="${env}-gateway-subnet"
  local mgmt_subnet="${env}-mgmt-subnet"
  local cluster_a_subnet="${env}-cluster-a-subnet"
  local cluster_b_subnet="${env}-cluster-b-subnet"
  local address_name="${env}-vpn-gw-public-ip"

  echo
  echo "=== Creating Pattern 2 environment: ${env} ==="

  ensure_network "${network}"
  ensure_subnet "${gateway_subnet}" "${network}" "10.${octet}.10.0/24"
  ensure_subnet "${mgmt_subnet}" "${network}" "10.${octet}.15.0/24"
  ensure_subnet "${cluster_a_subnet}" "${network}" "10.${octet}.20.0/24"
  ensure_subnet "${cluster_b_subnet}" "${network}" "10.${octet}.30.0/24"

  ensure_address "${address_name}"

  create_common_firewall "${env}" "${network}" "10.${octet}.15.0/24" "10.${octet}.20.0/24,10.${octet}.30.0/24"

  ensure_firewall "${env}-allow-vxlan-between-cluster-nodes" \
    --network="${network}" \
    --allow=udp:4789 \
    --source-ranges="10.${octet}.20.0/24,10.${octet}.30.0/24" \
    --target-tags="${env}-node"

  ensure_firewall "${env}-allow-cluster-east-west" \
    --network="${network}" \
    --allow=tcp,udp,icmp \
    --source-ranges="10.${octet}.20.0/24,10.${octet}.30.0/24" \
    --target-tags="${env}-node"

  create_management_vm "${env}" "${network}" "${mgmt_subnet}"
  create_appliance_one_nic "${env}" "${network}" "${gateway_subnet}" "${address_name}"

  for i in 1 2 3 4; do
    create_pattern2_node "${env}" "${network}" "${cluster_a_subnet}" "${cluster_b_subnet}" "${i}"
  done
}

print_summary() {
  echo
  echo "=== Deployment summary ==="
  gcloud compute instances list \
    --filter='name~(p1a|p1b|p2a|p2b)' \
    --format='table(name,zone,machineType.basename(),networkInterfaces[].networkIP,networkInterfaces[].accessConfigs[].natIP,tags.items.list())'

  echo
  echo "Management access examples:"
  echo "  gcloud compute ssh p1a-mgmt --zone=${ZONE} --tunnel-through-iap"
  echo "  gcloud compute ssh p1b-mgmt --zone=${ZONE} --tunnel-through-iap"
  echo "  gcloud compute ssh p2a-mgmt --zone=${ZONE} --tunnel-through-iap"
  echo "  gcloud compute ssh p2b-mgmt --zone=${ZONE} --tunnel-through-iap"

  echo
  echo "Important next steps:"
  echo "  1. Confirm the selected appliance profile image is correct for your Marketplace entitlement or custom image."
  echo "  2. Configure appliance-local credentials and disable any unwanted cloud-init access path."
  echo "  3. Configure IPsec tunnels from the external hub to each appliance public IP."
  echo "  4. Configure appliance static routes, NAT, firewall policy, VXLAN, Docker IPVLAN, and evidence capture as required."
}

main() {
  ensure_project

  create_pattern1 "p1a" "21"
  create_pattern1 "p1b" "22"
  create_pattern2 "p2a" "23"
  create_pattern2 "p2b" "24"

  print_summary
}

main "$@"
